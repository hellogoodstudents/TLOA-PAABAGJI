import pickle
import numpy as np
import math
import time



# 干扰取链路裕量1倍
Interference_distance = [
    [3, 4.77, 15, 20],
]



def load_layout_result():
    """
    从文件中加载 layout_result 和 nodes_first。
    """
    # 加载 layout_result
    with open("layout_result.pkl", "rb") as f:
        layout_result0 = pickle.load(f)
        layout_result = [row[:5] for row in layout_result0]   # 只保留前5列数据,第一次打开后，不考虑，已设置的功率、剩余能量
        # 给每行新增第 5 列为 0
        for row in layout_result:
                row.append(0)

    # 加载 nodes_first
    with open("nodes_first.pkl", "rb") as f:
        nodes_first = pickle.load(f)

    return layout_result, nodes_first


def save_layout_result(layout_result):
    """
    将更新后的 updated_layout_result 保存到文件中。
    """
    with open("layout_result.pkl", "wb") as f:
        pickle.dump(layout_result, f)
    print("更新后的 layout_result 已保存到文件中。")

def save_interference_info(interference_info):
    """
    将interference_info保存到文件中。
    """
    with open("interference_info.pkl", "wb") as f:
        pickle.dump(interference_info, f)
    print("通信节点的方位信息 interference_info 已保存到文件中。")



def custom_round(num):   #小数点后保留2位，0舍1进
    return (int(num * 100) + (num * 100 % 1 > 0)) / 100


# 传播损耗计算公式
L_sight = lambda d: 30 * np.log10(d) + 20 * np.log10(600) + 32.5
L_two_ray = lambda d, h_t, h_r: (
        30 * np.log10(d) - 20 * np.log10(max(h_t, 1e-10)) - 20 * np.log10(max(h_r, 1e-10)) + 120
)

# 功放最大功率
MAX_POWER_GROUND_JAMMER = 90  # 地面干扰机最大功率为90W
MAX_POWER_AIR_JAMMER = 45  # 空中干扰机最大功率为45W



# 通信节点接收干扰功率的计算，Gtr为链路功率增益，Lpc取固定值1。视距传播中Lc_j为L_sight，双线传播中Lc_j为L_two_ray，Pt_j 为干扰机的干扰功率数值
Prj = lambda Pt_j, Gtr, Lc_j: Pt_j + Gtr - Lc_j - 1



def calculate_azimuth(x1, y1, x2, y2):
    """计算水平方位角"""
    dx = x2 - x1
    dy = y2 - y1
    azimuth = np.arctan2(dy, dx)
    return round(np.rad2deg(azimuth),2)



def calculate_elevation(x1, y1, z1, x2, y2, z2):
    """计算垂直俯仰角"""
    dx = x2 - x1
    dy = y2 - y1
    dz = z2 - z1
    distance_2d = np.sqrt(dx ** 2 + dy ** 2)
    elevation = np.arctan2(dz, distance_2d)
    return round(np.rad2deg(elevation),2)




def generate_interference_info(nodes_first, layout_result):
    result = []
    for jammer in layout_result:
        jammer_id = jammer[0]
        jammer_type = jammer[1]
        jammer_x = jammer[2]
        jammer_y = jammer[3]
        jammer_z = jammer[4]

        current_jammer_info = [jammer_id]
        for comm_node in nodes_first:
            comm_id = comm_node[0]
            comm_type = comm_node[1]
            comm_x = comm_node[2]
            comm_y = comm_node[3]
            comm_z = comm_node[4]

            distance = calculate_distance(jammer_x, jammer_y, jammer_z, comm_x, comm_y, comm_z)

            if (jammer_type == 0 and comm_type == 2 and distance <= 15) or (
                    not (jammer_type == 0 and comm_type == 2) and distance <= 20):      #干扰机和通信节点之间的距离不大于限定范围
                azimuth = calculate_azimuth(jammer_x, jammer_y, comm_x, comm_y)
                if jammer_type == 0 and comm_type == 2:
                    elevation = 0
                else:
                    elevation = calculate_elevation(jammer_x, jammer_y, jammer_z, comm_x, comm_y, comm_z)

                current_jammer_info.extend([comm_id, azimuth, elevation])

        if len(current_jammer_info) > 1:  # 确保干扰机至少对一个通信节点有干扰信息
            result.append(current_jammer_info)

    return result



def calculate_received_power(jammer, comm_node):
    """计算通信节点在干扰机位置处的收信功率"""
    jammer_type = jammer[1]
    communication_type = comm_node[1]
    distance = calculate_distance(jammer[2], jammer[3], jammer[4], comm_node[2], comm_node[3], comm_node[4])

    if jammer_type == 0 and communication_type == 2:  # 地面干扰机对地面通信节点的影响
        interference_distance = Interference_distance[0][2]  # 双线传播的纳入计算的范围
        Gtr = 4.5
        h_t = 8
        h_r = 3
        loss = L_two_ray(distance, h_t, h_r)
    else:
        loss = L_sight(distance)
        interference_distance = Interference_distance[0][3]  # 视距传播的纳入计算的范围
        if communication_type == 2:  # 空中干扰机对地面通信节点的影响
            Gtr = 4.5
        else:  # 干扰机对空中通信节点的影响
            Gtr = 4


    if interference_distance is not None and distance <= interference_distance:
        # 检查 comm_node[7] 是否为正数
        if comm_node[8] > 0:
            transmit_power_dBW = 10 * math.log10(comm_node[8])
        else:
            transmit_power_dBW = -1000
        # 计算收信功率，通信节点的线缆损耗为1dB
        received_power = transmit_power_dBW + Gtr - loss - 1
    else:
        received_power = -1000  # 如果没有纳入计算的干扰距离，返回0值

    return round(received_power,2)


def reverse_calculate_transmit_power(jammer, comm_node, received_power):
    """根据干扰机位置的收信功率反向计算通信节点的发信功率"""
    jammer_type = jammer[1]
    communication_type = comm_node[1]
    distance = calculate_distance(jammer[2], jammer[3], jammer[4], comm_node[2], comm_node[3], comm_node[4])

    if jammer_type == 0 and communication_type == 2:  # 地面干扰机对地面通信节点的影响
        interference_distance = Interference_distance[0][2]  # 双线传播的纳入计算的范围
        Gtr = 4.5
        h_t = 8
        h_r = 3
        loss = L_two_ray(distance, h_t, h_r)
    else:
        loss = L_sight(distance)
        interference_distance = Interference_distance[0][3]  # 视距传播的纳入计算的范围
        if communication_type == 2:  # 空中干扰机对地面通信节点的影响
            Gtr = 4.5
        else:  # 干扰机对空中通信节点的影响
            Gtr = 4

    if interference_distance is not None and distance <= interference_distance:
        # 反向计算发信功率
        transmit_power_dBW = received_power - Gtr + loss + 1
        transmit_power = 10 ** (transmit_power_dBW / 10)
    else:
        transmit_power = 0

    return round(transmit_power,2)




def update_nodes_first(nodes_first, layout_result, interference_info, received_power_info):
    new_nodes_first = nodes_first.copy()
    for row in new_nodes_first:
        row[8] = -1000

    for savedjammer in interference_info:
        jammer_id = savedjammer[0]
        for realjammer in received_power_info:
            if realjammer[0] == jammer_id:    #选择对应的通信节点信息，使用搜索寻找

                for i in range(1, len(savedjammer), 3):
                    comm_node_id = savedjammer[i]
                    saved_azimuth = savedjammer[i + 1]
                    saved_elevation = savedjammer[i + 2]

                    for j in range(1, len(realjammer), 4):
                        #real_comm_node_id = realjammer[j]
                        real_azimuth = realjammer[j + 1]
                        real_elevation = realjammer[j + 2]
                        received_power = realjammer[j + 3]
                        #print('received_power', received_power)

                        if  abs(saved_azimuth - real_azimuth) <= 0.3 and abs(
                                saved_elevation - real_elevation) <= 0.3:
                            # 找到匹配的通信节点，计算发信功率
                            jammer = layout_result[jammer_id - 1]  # 假设干扰机索引从1开始
                            comm_node = nodes_first[comm_node_id - 1]  # 假设通信节点索引从1开始
                            transmit_power = reverse_calculate_transmit_power(jammer, comm_node, received_power)
                            # 更新new_nodes_first中对应通信节点的第9列（发信功率）
                            #print('transmit_power',transmit_power)
                            if transmit_power > new_nodes_first[comm_node_id - 1][8]:
                                new_nodes_first[comm_node_id - 1][8] = transmit_power


    #print('干扰机侦查得到的new_nodes_first:',new_nodes_first)
        # 计算每个通信节点的最大收信功率并更新第9列
    for i in range(new_nodes_first.shape[0]):
        max_Pr = -1000  # 初始化最大收信功率为-1000
        for j in range(new_nodes_first.shape[0]):
            if i == j:  # 跳过自身
                continue
            else:
                # 获取目标节点的发送功率
                Pt_min = new_nodes_first[j, 8]
                if Pt_min != -1000:  # 如果目标节点的发送功率有效
                    # 计算收信功率
                    d = np.sqrt((new_nodes_first[i, 2] - new_nodes_first[j, 2]) ** 2 + (
                                new_nodes_first[i, 3] - new_nodes_first[j, 3]) ** 2 + (
                                        new_nodes_first[i, 4] - new_nodes_first[j, 4]) ** 2) / 1000

                    if new_nodes_first[i, 1] == 2 and new_nodes_first[j, 1] == 2:
                        Gtr = 5
                        Lc_j = L_two_ray(d, 8, 8)   #地面通信节点的天线高度为8m
                    elif new_nodes_first[i, 1] == 1 and new_nodes_first[j, 1] == 1:
                        Lc_j = L_sight(d)
                        Gtr = 4
                    else:
                        Lc_j = L_sight(d)
                        Gtr = 4.5

                    # 计算收信功率
                    Pr = Pt_min + Gtr - Lc_j - 1  +0.3  ########## 通信节点的线缆损耗为1dB,  0.4dB估计的损失裕量，约1.1倍

                    # print('', new_nodes_first[i, 0], new_nodes_first[j, 0], Pt_min, Gtr, Lc_j, Pr)
                    if Pr > max_Pr:  # 更新最大收信功率
                        max_Pr = Pr

        # 更新第7列为最大收信功率
        new_nodes_first[i, 9] = round(float(max_Pr), 2)  # 存储为保留两位小数的浮点数

    return new_nodes_first




def generate_received_power_info(nodes_first, layout_result):  #产生通信节点在干扰机位置处的收信功率信息，真实环境的模拟值
    result = []
    for jammer in layout_result:
        jammer_id = jammer[0]
        current_jammer_info = [jammer_id]
        for comm_node in nodes_first:
            comm_id = comm_node[0]
            received_power = calculate_received_power(jammer, comm_node)
            if received_power != -1000:
                # 再增方位角和俯仰角
                azimuth = calculate_azimuth(jammer[2], jammer[3], comm_node[2], comm_node[3])
                elevation = calculate_elevation(jammer[2], jammer[3], jammer[4], comm_node[2], comm_node[3],
                                                comm_node[4])
                current_jammer_info.extend([comm_id, azimuth, elevation,received_power])

        if len(current_jammer_info) > 1:  # 确保干扰机至少对一个通信节点有干扰信息
            result.append(current_jammer_info)

    return result













def calculate_distance(x1, y1, z1, x2, y2, z2):
    """计算三维欧氏距离"""
    return np.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2 + (z1 - z2) ** 2)/1000


def calculate_path_loss(jammer, communication_node):
    """计算路径损耗"""
    jammer_type = jammer[1]
    comm_type = communication_node[1]
    d = calculate_distance(jammer[2], jammer[3], jammer[4], communication_node[2], communication_node[3], communication_node[4])
    h_t = jammer[4]
    h_r = communication_node[4]

    if jammer_type == 0 and comm_type == 2:  # 地面干扰机对地面通信节点的影响,双线传播
        interference_distance = Interference_distance[0][2]  # 双线传播的纳入计算的范围
        if interference_distance is not None and d <= interference_distance:
            loss = L_two_ray(d, h_t, h_r)
        else:
            loss = 1000 #假设无线传播损耗为1000dB，不通
    else:
        interference_distance = Interference_distance[0][3]  # 视距传播的纳入计算的范围
        if interference_distance is not None and d <= interference_distance:
            loss = L_sight(d)
        else:
            loss = 1000  # 假设无线传播损耗为1000dB，不通

    return loss

def update_jammer_info(comm_node,jammer, power, num_amplifiers):
    """分配功率到功放，输入了一个干扰机"""
    # 初始化 remaining_power
    Gtr = 4.5 if comm_node[1] == 2 else 4  # 链路功率增益
    loss = calculate_path_loss(jammer, comm_node)

    power = power
    if power == 0:
        remaining_power = 0
    else:
        required_power_dBW = 10 * math.log10(power)   # 转换为dBW
        jammer_power_dBW = required_power_dBW - Gtr + loss + 1  # 由该通信节点处成功干扰所需的干扰信号功率，计算出该干扰机处需要发送的干扰信号功率数值
        remaining_power = custom_round((10 ** (jammer_power_dBW / 10))  )# 转换为w,小数点后保留2位，0舍1进
    # 初始化 amplifiers 列表
    # 判断功放是否已使用
    if len(jammer) > 5 and jammer[5] != 0:  # 功放已使用
        # 获取干扰机信息第5 位的内容，即功放信息
        amplifiers = jammer[5]
    else:  # 功放未使用
        amplifiers = 0

    # 地面干扰机最大功率为90W，空中干扰机最大功率为45W
    max_power = MAX_POWER_GROUND_JAMMER if jammer[1] == 0 else MAX_POWER_AIR_JAMMER

    # 分配功率到功放
    if remaining_power > 0:
        new_power = amplifiers + remaining_power
        if new_power <= max_power:
            amplifiers = new_power
            remaining_power = 0
        else:
            remaining_power = new_power - max_power
            amplifiers = max_power
    else:
        pass

    # 如果 jammer 的长度不足以容纳功放信息，则扩展 jammer 列表
    required_length = 5 + num_amplifiers
    if len(jammer) < required_length:
        jammer.extend([0] * (required_length - len(jammer)))

    # 更新功放功率
    if amplifiers != 0:  # 只有当功放功率不为0时，才设置功率，即干扰机的发信功率
        jammer[5] = custom_round(amplifiers)  #设置功放功率,小数点后保留2位，0舍1进
    else:
        jammer[5] = 0  # 功率设置为0（无效值）w

    # 计算通信节点处剩余总功率
    if remaining_power == 0:
        comun_jammer_power = 0
    else:
        remaining_power_dBW = 10 * math.log10(remaining_power)   # 转换为dBW
        comun_jammer_power_dBW = remaining_power_dBW + Gtr - loss - 1
        comun_jammer_power = 10 ** (comun_jammer_power_dBW / 10)  # 转换为w

    return jammer, comun_jammer_power  # 返回更新后的干扰机和剩余功率（通信节点处，需要的干扰功率）

def calculate_interference_power(jammer, comm_node, total_power):
    """计算单个干扰机在单个通信节点处造成的干扰功率，不含环境噪声"""
    jammer_type = jammer[1]
    communication_type = comm_node[1]
    distance = calculate_distance(jammer[2], jammer[3], jammer[4], comm_node[2], comm_node[3], comm_node[4])

    if jammer_type == 0 and communication_type == 2:  # 地面干扰机对地面通信节点的影响
        interference_distance = Interference_distance[0][2]  # 双线传播的纳入计算的范围
        Gtr = 4.5
        h_t = 8
        h_r = 3
        loss = L_two_ray(distance, h_t, h_r)
    else:
        loss = L_sight(distance)
        interference_distance = Interference_distance[0][3]  # 视距传播的纳入计算的范围
        if communication_type == 2:  # 空中干扰机对地面通信节点的影响
            Gtr = 4.5
        else:  # 干扰机对空中通信节点的影响
            Gtr = 4

    if interference_distance is not None and distance <= interference_distance:
        # 计算所有与通信节点同频段的功放的功率之和
        total_power = total_power
        # 将总功率转换回 dBW
        if total_power > 0:
            total_power_dBW = 10 * math.log10(total_power)
        else:
            total_power_dBW = -1000  # 如果没有功放工作，返回无效值
        # 计算干扰功率，通信节点的线缆损耗为1dB
        interference_power = total_power_dBW + Gtr - loss - 1

    else:
        interference_power = -1000  # 如果没有纳入计算的干扰距离，返回0值

    return interference_power

def calculate_required_interference_power(comm_node, jammer_list):
    """
    计算通信节点成功干扰所需的干扰功率，并减去已有的同频段干扰机功放的干扰接收信号,得到单个干扰机所需要释放的干扰功率
    """
    required_power_w  = 3 * 10 ** (comm_node[9] / 10) - 3.16e-12   # 通信节点成功干扰所需的干扰功率  通信接受功率转化为w， 干信比为3倍，减去环境噪声-115dBW
    # 增加的0.05是抵消，多次运算中，单位转化的损耗

    for jammer in jammer_list:  # 逐个计算已使用同频段干扰机的干扰功率，并减去，其它干扰机已施加的功率
        # 计算所有与该通信节点同频段的功放的功率之和
        if len(jammer) > 5:
            total_power = jammer[5]  # 第5位为功率

            if total_power > 0:
                interference_power = calculate_interference_power(jammer, comm_node, total_power)  # 计算单个干扰机在单个通信节点处造成的干扰功率,dBW
                if interference_power != -1000:
                    required_power_w = required_power_w - 10 ** (interference_power / 10)  # 将功率从 dBW 转换为 W 并累减，减去同频段干扰机的干扰接收信号
                else:
                   pass
        else:
            pass

    if required_power_w <= 0:
        required_power_w = 0  # 如果没有功放工作，返回无效值  0W

    return required_power_w  # 单位为W

def select_best_jammers(comm_node, jammer_list):
    """
    选择路径损耗最小的干扰机，按顺序，自小往大，返回可用的干扰机。
    """
    jammer_loss = []
    for jammer in jammer_list:
        loss = calculate_path_loss(jammer, comm_node)
        if loss != 1000:#干扰机在纳入计算的范围内
            jammer_loss.append((jammer, loss))

    # 按路径损耗排序，选择前 num_jammers 个干扰机
    jammer_loss.sort(key=lambda x: x[1])
    return [x[0] for x in jammer_loss]

def allocate_interference_power(comm_node, jammer_list):
    """
    通信节点为一个节点，干扰机为多个节点

    分配干扰功率到干扰机的功放中，设置功率和频段。
    """
    required_power = calculate_required_interference_power(comm_node, jammer_list)      #单位为W 通信节点位置成功干扰所需的干扰功率，对于该干扰机，减去已有的同频段干扰机功放的干扰接收信号

    best_jammers = select_best_jammers(comm_node, jammer_list)  # 干扰路径最小的干扰机

    for jammer in best_jammers:  # 逐次分配功率到单个干扰机的功放中，设置功率和频段
        num_amplifiers = 1  # 功放数量，地面干扰机和空中干扰机均为1个
        jammer, required_power = update_jammer_info(comm_node,jammer, required_power, num_amplifiers)    # 返回更新后的干扰机和剩余总功率
        if required_power <= 0:
            break  # 如果功率需求已满足，则退出循环

    if required_power > 0:
        print(f"无法满足通信节点 {comm_node[0]} 的干扰需求，剩余功率需求: {required_power} W, 请增加干扰机数量或调整干扰机功率。")



# 示例：加载并打印数据
def main_jammer_run():


    layout_result, nodes_first = load_layout_result()
    #print("layout_result:", layout_result)
    #print("nodes_first:", nodes_first)

    # 仿真获取通信节点在干扰机位置处的收信功率信息,真实的环境
    received_power_info = generate_received_power_info(nodes_first, layout_result)
    # print("通信节点在干扰机位置处的收信功率信息：", received_power_info)

    # 记录干扰资源调度算法程序开始时间
    start_time = time.time()

    interference_info = generate_interference_info(nodes_first, layout_result)  #干扰机处理通信节点信息，并存储
    #print("干扰机与通信节点的位置方位信息：", interference_info)
    save_interference_info(interference_info) #保存干扰机与通信节点的位置方位信息

    # 依据干扰机侦查信息，更新nodes_first列表
    nodes_first = update_nodes_first(nodes_first, layout_result, interference_info, received_power_info)
    #print("干扰机侦查，更新后的nodes_first：", nodes_first)





    # 处理 nodes_first 数据
    data = []
    # 假设 nodes_first 是二维 numpy 数组
    if isinstance(nodes_first, np.ndarray):
        for row in nodes_first:
            data.append(row)
    else:
        # 如果不是 numpy 数组，按照原来的字符串处理方式
        lines = nodes_first.strip().split('\n')
        for line in lines:
            # 去除方括号和多余的空格
            line = line.replace('[', '').replace(']', '').strip()
            if line:
                data.append(line)

    # 提取所需的列组成新的列表
    communication_result = []
    for row in data:
        # 提取第 1 列、到第9列
        new_row = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9]]
        communication_result.append(new_row)

    #print("communication_result转换后的结果:", communication_result)

    # 为每个具有收信功能的通信节点分配干扰功率
    for comm_node in communication_result:
        if comm_node[9] == -1000:  # 如果通信节点的接收功率为-1000dBW(即为0)，跳过
            continue
        else:
            allocate_interference_power(comm_node, layout_result)  # 分配干扰功率到单个干扰机的功放中，设置功率和频段

    # 遍历 layout_result，检查每一行的第6列
    for row in layout_result:
        if len(row) < 6:  # 如果第6列不存在
            row.append(0)  # 将第6列设置为0
        elif row[5] is None:  # 如果第6列存在但为None
            row[5] = 0  # 将第6列设置为0

    # 计算干扰机的剩余能量
    air_time = land_time = 0.025  # 干扰机工作时间（小时），1.5分钟
    efficiency = 0.95  # 能量转换效率,正常干扰的电量使用上限

    # 遍历 layout_result，计算每个干扰机的剩余能量
    for row in layout_result:

        if row[1] == 0:  # 地面干扰机
            P_landtotal = row[5]  # 地面干扰机的功率
            land_energy = land_time * (4 + P_landtotal) / (efficiency * 24)  # 计算能量消耗
            if len(row) < 7:  # 如果第7列不存在，则扩展列表:
                row.append(0)
                land_energy_initial = 20  # 地面干扰机初始能量（单位：Ah）
            else:
                if row[6] > 0:
                    land_energy_initial = row[6]  # 地面干扰机初始剩余能量（单位：Ah）
                else:
                    print(f"第{row[0]}行的剩余能量值无效：{row[6]}")
                    break
            land_energy_remain = land_energy_initial - land_energy  # 计算剩余能量
            row[6] = round(land_energy_remain, 3)  # 将剩余能量存储在第7列
        elif row[1] == 1:  # 空中干扰机
            P_airtotal = row[5]  # 空中干扰机的功率
            air_energy = air_time * (4 + P_airtotal) / (efficiency * 24)  # 计算能量消耗
            if len(row) < 7:  # 如果第7列不存在，则扩展列表:
                row.append(0)
                air_energy_initial = 12  # 空中干扰机初始能量（单位：Ah）
            else:
                if row[6] > 0:
                    air_energy_initial = row[6]  # 空中干扰机初始剩余能量（单位：Ah）
                else:
                    print(f"第{row[0]}行的剩余能量值无效：{row[6]}")
                    break
            air_energy_remain = air_energy_initial - air_energy  # 计算剩余能量
            row[6] = round(air_energy_remain, 3)  # 将剩余能量存储在第7列


    print("更新后的 layout_result（包含剩余能量）：", layout_result)

    # 保存更新后的 layout_result
    save_layout_result(layout_result)

    # 记录程序结束时间
    end_time = time.time()
    # 计算程序运行时长
    elapsed_time = end_time - start_time

    return layout_result, elapsed_time


if __name__ == "__main__":
    layout_result, elapsed_time = main_jammer_run()
    print(f"程序运行时长: {elapsed_time} 秒")