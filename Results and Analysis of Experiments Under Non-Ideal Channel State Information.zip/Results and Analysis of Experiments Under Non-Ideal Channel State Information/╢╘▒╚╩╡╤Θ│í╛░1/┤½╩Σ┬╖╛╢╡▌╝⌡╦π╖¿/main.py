from generate_nodes import generate_nodes
from modify_communication_nodes import modify_communication_nodes
import pickle
import numpy as np
import time
import test
import jammer_run
import jammer_first_run
# 导入 test.py 模块
#1.运行main，将生成的通信节点信息和干扰机信息（无剩余功率）保存到文件中（layout_result 和 nodes_first），表示未更新的干扰机信息。
# 2.运行jammer_first_run，第一次计算干扰机的剩余功率，将更新后的 干扰机信息 保存到文件updated_layout_result中
#3.回到main，将updated_layout_result覆盖在layout_result中。
# 4.运行main，启动test，以新的干扰机信息和通信节点信息（layout_result和communication），进行测试，判断干扰是否符合干信比为3的要求。


def save_layout_result(layout_result, nodes_first):
    """
    将 layout_result 和 nodes_first 保存到文件中。
    """
    # 保存 layout_result
    with open("layout_result.pkl", "wb") as f:  #含干扰机剩余能量
        pickle.dump(layout_result, f)

    # 保存 nodes_first
    with open("nodes_first.pkl", "wb") as f:
        pickle.dump(nodes_first, f)

    print("layout_result 和 nodes_first 已保存到文件中。")



def load_layout_result():
    """
    从文件中加载更新后的 updated_layout_result。
    """
    with open("layout_result.pkl", "rb") as f:
        layout_result = pickle.load(f)
    return layout_result

def load_nodes_first():
    """
    从文件中加载更新后的 nodes_first。
    """
    with open("nodes_first.pkl", "rb") as f:
        nodes_first = pickle.load(f)
    return nodes_first


def main():
    nodes_first = [
        [1, 1, 42800, 6500, 2000, 0.71, -94.03],
        [2, 1, 5800, 45800, 2100, 0.2, -97.87],
        [3, 1, 4600, 27300, 3000, 0.96, -100.57],
        [4, 1, 32100, 18600, 2200, 0.67, -105.13],
        [5, 1, 17200, 38400, 2000, 0.63, -99.87],
        [6, 2, 36700, 45800, 5, 0.55, -110.22],
        [7, 2, 46300, 4600, 5, 0.9, -90.05],
        [8, 2, 11000, 35900, 5, 0.25, -95.89],
        [9, 2, 44600, 33500, 5, 0.18, -109.33],
        [10, 2, 9000, 41200, 5, 0.42, -93.89],
        [11, 2, 26200, 5800, 5, 0.56, -105.21],
        [12, 2, 3500, 10000, 5, 0.48, -107.94],
        [13, 2, 29200, 500, 5, 0.78, -105.86],
        [14, 2, 21600, 12600, 5, 0.38, -103.27],
        [15, 2, 38600, 29800, 5, 0.85, -104.13],
        [16, 2, 15200, 17900, 5, 0.79, -105.41],
        [17, 2, 10400, 23900, 5, 0.74, -96.59],
        [18, 2, 46900, 17400, 5, 0.06, -102.76],
        [19, 2, 29800, 44800, 5, 0.09, -105.22],
        [20, 2, 23200, 23600, 5, 0.89, -101.15],
    ]

    # 将第7列内容全部换算成1，表示频段为1
    for node in nodes_first:
        node[6] = 1  # 第7列表示频段，设置为1

    # 调用 generate_nodes 函数，生成初始的通信节点信息
    nodes_first = generate_nodes(nodes_first)


    # 定义 layout_result，干扰机位置
    layout_result = [
        [1, 0, 42477, 8065, 3],
        [2, 0, 44438, 32062, 3],
        [3, 0, 4020, 26808, 3],
        [4, 0, 22607, 24095, 3],
        [5, 0, 36789, 45253, 3],
        [6, 0, 28452, 1172, 3],
        [7, 0, 9741, 35353, 3],
        [8, 0, 7296, 45367, 3],
        [9, 0, 10941, 25200, 3],
        [10, 0, 40060, 29823, 3],
        [11, 1, 25424, 5581, 1300],
        [12, 0, 15887, 19078, 3],
        [13, 0, 16810, 37403, 3],
        [14, 1, 9355, 41961, 1200],
        [15, 0, 31620, 17562, 3],
        [16, 0, 28781, 45530, 3],
        [17, 0, 21217, 11331, 3],
        [18, 0, 4318, 10970, 3],
        [19, 0, 47780, 16447, 3],
        [20, 1, 42361, 5021, 1300],
        [21, 0, 43572, 6112, 3],
        [22, 1, 43678, 4116, 1129],
        [23, 1, 18678, 21116, 1129],
        [24, 0, 9217, 41331, 3],
        [25, 0, 7017, 24331, 3],
        [26, 0, 19017, 18331, 3],
        [27, 0, 42017, 30331, 3],
        [28, 1, 34417, 44331, 1003],
    ]

    # 保存 layout_result 和 nodes_first 到文件
    save_layout_result(layout_result, nodes_first)

    # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

    layout_result, elapsed_time = jammer_first_run.main_jammer_run()


    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中

    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中
    with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
        f.write(f"1次循环通信干扰决策\n")
        f.write(f"程序运行时长: {elapsed_time} 秒\n")
        f.write("layout_result数据:\n")
        for item in layout_result:
            f.write(f"{item}\n")

    # 加载第一次干扰更新后的 layout_result，干扰机序号、类型、x、y、z、功率w、剩余能量AH
    updated_layout_result = load_layout_result()
    #print("第一次更新后的 干扰机layout_result：", updated_layout_result,)



    #  将更新后的 updated_layout_result 保存到文件中 保存到 jammer.pkl 供 test.py 使用  ,不含干扰机剩余能量



    # 删除第 7、8 列数据（索引为 6、7）,对初始的通信节点nodes_first，处理，
    #communication2 含序号、类型、x坐标、y坐标、z坐标、天线高度、威慑度、该节点的最低发信功率（dBW）、该节点的最大收信功率（dBW）
    columns_to_delete = [6, 7]
    communication2 = np.delete(nodes_first, columns_to_delete, axis=1)
    # 将 communication2 转换为列表
    communication2 = communication2.tolist()

    print('communication2:')
    for row in communication2:
        print(row)

    # 将 communication2 保存到 communication.pkl 供 test.py 使用
    with open("communication.pkl", "wb") as f:
        pickle.dump(communication2, f)


    # 调用 test.py 的测试函数
    test_result = test.run_test(communication2, updated_layout_result)

    # 根据测试结果输出信息
    if test_result["success"]:
        print("通信干扰成功！")
    else:
        print("以下通信节点不符合干信比为3的干扰：")
        for warning in test_result["warnings"]:
            print(warning)


    # 依据成功干扰后的communication，生成新的通信信息，读取含剩余能量的layout_result,得到新的干扰机信息layout_result
    i = 2  # 初始化循环次数
    while True:
        communication = modify_communication_nodes()
        print('功率调整后的通信方', communication)  # 序号、类型、x坐标、y坐标、z坐标、天线高度、威慑度、该节点的最低发信功率（dBW）、该节点的最大收信功率（dBW）

        # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

        layout_result, elapsed_time = jammer_run.main_jammer_run()




        # 调用 test.py 的测试函数
        test_result = test.run_test(communication, layout_result)

        # 根据测试结果输出信息
        if test_result["success"]:
            print(f"第{i}次通信干扰成功！")
            # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,有用的次数减1
            with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                f.write(f"{i}次循环通信干扰决策\n")
                f.write(f"程序运行时长: {elapsed_time} 秒\n")
                f.write("layout_result数据:\n")
                for item in layout_result:
                    f.write(f"{item}\n")

            i += 1  # 循环次数加1

        else:
            print(f"第{i}次通信干扰失败！")
            print("以下通信节点达不到不符合干信比为3的干扰：")
            for warning in test_result["warnings"]:
                print(warning)

            # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,保留最后失败的干扰数据，有用的次数减1
            with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                f.write(f"{i}次循环通信干扰决策\n")
                f.write(f"程序运行时长: {elapsed_time} 秒\n")
                f.write("layout_result数据:\n")
                for item in layout_result:
                    f.write(f"{item}\n")




            break  # 通信干扰失败，停止循环


    layout_result = load_layout_result()
    print("干扰失败后，最后更新后的 干扰机layout_result：", layout_result)


if __name__ == '__main__':
    for _ in range(30):  #程序运行30次
        main()