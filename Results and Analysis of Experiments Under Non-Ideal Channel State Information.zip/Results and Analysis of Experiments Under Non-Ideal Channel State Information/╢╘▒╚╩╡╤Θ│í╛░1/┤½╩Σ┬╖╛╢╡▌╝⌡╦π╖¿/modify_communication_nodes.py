# modify_communication_nodes.py
import numpy as np
import random
import pickle

L_sight = lambda d: 30 * np.log10(d) + 20 * np.log10(600) + 32.5

# 双线传播损耗计算公式，其中d为干扰机与通信设备的间距，h_t和h_r数值依据干扰机类型与通信节点类型进行定义
L_two_ray = lambda d, h_t, h_r: (
        40 * np.log10(d) - 20 * np.log10(max(h_t, 1e-10)) - 20 * np.log10(max(h_r, 1e-10)) + 120
)

# 通信节点发信功率的计算，Gtr为链路功率增益，Lpc取固定值1。视距传播中Lc_j为L_sight，双线传播中Lc_j为L_two_ray
Pt_j_min = lambda Gtr, Lc_j: -103 - Gtr + Lc_j + 1  # 设定本场景中，通信设备的通信链路裕量为12dB，环境噪声为-115dBW，通信设备接受灵敏度为-127dBW，即要求通信设备的收信功率要大于-103dBW,程序有0.5的单位转化损耗



def load_nodes_first():
    """
    从文件中加载更新后的 nodes_first。即通信节点的初始信息列表，包含序号、类型、x坐标、y坐标、z坐标、天线高度、威慑度、频段、
                        与该节点路径损耗最小的通信目标节点、该节点的最低发信功率、该节点的最大收信功率，正常通信的信息
    """
    with open("nodes_first.pkl", "rb") as f:
        nodes_first = pickle.load(f)
    return nodes_first


def load_communication():
    """
    从文件中加载更新后的 communication信息。
    """
    with open("communication.pkl", "rb") as f:
        communication = pickle.load(f)
    return communication


def modify_communication_nodes():
    """
    修改通信节点的策略。

    参数:
    nodes_first (list): 通信节点的初始信息列表，包含序号、类型、x坐标、y坐标、z坐标、天线高度、威慑度、频段、
                        与该节点路径损耗最小的通信目标节点、该节点的最低发信功率、该节点的最大收信功率

    返回:
    np.ndarray: 修改后的通信节点信息数组
    """
    # 将列表转换为 numpy 数组以便于处理
    nodes = load_communication()
    nodes = np.array(nodes, dtype=object)

    print('communication_nodes',nodes)

    # 遍历所有节点，调整发信功率
    for i in range(nodes.shape[0]):
        # 获取节点类型和当前发信功率
        node_type = nodes[i, 1]
        current_power = nodes[i, 6]

        # 确定功率上限
        if node_type == 1:
            power_limit = 10  # 空中站最大发信功率为 最大发信功率为10dBW,10w
        else:
            power_limit = 13.98  # 地面站最大发信功率为 13.98dBW，25w

        # 根据当前发信功率是否达到最大值，选择不同的调整策略
        if current_power < power_limit:
            if current_power == -1000:
                nodes_first = load_nodes_first()
                rand_num = np.random.random()
                if rand_num < 0.3:
                    newp = nodes_first[i, 8]  # 恢复正常通信的初始功率
                    nodes[i, 6] = round(newp, 2)
                elif rand_num < 0.6:
                    if nodes_first[i, 8] == -1000:   #如果初始功率为-1000，随机选择一个功率（大于0）
                        newp = random.uniform(0, power_limit)  # 在0功率和功率上限之间随机选择一个功率
                    else:
                        newp = random.uniform(nodes_first[i, 8], power_limit)  # 在正常功率和功率上限之间随机选择一个功率
                    nodes[i, 6] = round(newp, 2)
                else:
                    pass  # 不做任何调整
            else:  # 当前功率不为 -1000
                rand_num = np.random.random()
                # 0.3 倍的概率，发信功率增大 3dBW
                if rand_num < 0.3:
                    new_power = current_power + 3
                    if new_power > power_limit:
                        new_power = power_limit
                # 0.2 倍的概率，发信功率增大 6dBW
                elif rand_num < 0.5:
                    new_power = current_power + 6
                    if new_power > power_limit:
                        new_power = power_limit
                # 0.3 倍的概率，发信功率维持不变
                elif rand_num < 0.8:
                    new_power = current_power
                # 0.2 倍的概率，发信功率设置为 -1000dBW，即停止发信
                else:
                    new_power = -1000
                nodes[i, 6] = round(new_power,2)
        else:
            rand_num = np.random.random()
            # 0.6 倍的概率，发信功率设置为 -1000dBW，即停止发信
            if rand_num < 0.6:
                new_power = -1000
            # 0.4 倍的概率，发信功率维持不变
            else:
                new_power = current_power
            nodes[i, 6] = round(new_power,2)

            # 再次计算每个通信节点的最大收信功率并更新第8列



        for i in range(nodes.shape[0]):
            max_Pr = -1000  # 初始化最大收信功率为-1000
            for j in range(nodes.shape[0]):
                if i == j:  # 跳过自身
                    continue
                else:
                    # 获取目标节点的发送功率
                    Pt_min = nodes[j, 6]
                    if Pt_min != -1000:  # 如果目标节点的发送功率有效
                        # 计算收信功率
                        # 根据节点类型确定Gtr
                        if nodes[i, 1] == 1 and nodes[j, 1] == 1:
                            Gtr = 4
                        elif nodes[i, 1] == 2 and nodes[j, 1] == 2:
                            Gtr = 5
                        else:
                            Gtr = 4.5
                        d = np.sqrt((nodes[i, 2] - nodes[j, 2]) ** 2 + (nodes[i, 3] - nodes[j, 3]) ** 2 + (
                                    nodes[i, 4] - nodes[j, 4]) ** 2) / 1000
                        if nodes[i, 1] == 2 and nodes[j, 1] == 2:
                            Lc_j = L_two_ray(d, nodes[i, 4], nodes[j, 4])
                        else:
                            Lc_j = L_sight(d)
                        # 计算收信功率

                        Pr = Pt_min + Gtr - Lc_j - 1  # 通信节点的线缆损耗为1dB
                        # print('', nodes[i, 0], nodes[j, 0], Pt_min, Gtr, Lc_j, Pr)
                        if Pr > max_Pr:  # 更新最大收信功率
                            max_Pr = Pr

            # 更新第10列为最大收信功率
            nodes[i, 7] = round(float(max_Pr), 2)  # 存储为保留两位小数的浮点数



    # 将 nodes 转换为列表
    nodes = nodes.tolist()

    # 保存 nodes
    with open("communication.pkl", "wb") as f:
        pickle.dump(nodes, f)

    return nodes




#communication = modify_communication_nodes()
#print('功率调整后的通信方',communication)