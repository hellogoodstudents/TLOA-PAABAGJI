import pickle
import numpy as np
import math
import time
import pickle
import time
import test
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import random


# 干扰取链路裕量1倍
Interference_distance = [
    [3, 4.77, 15, 20],
]



def load_layout_result():
    """
    从文件中加载 layout_result 和 nodes_first。
    """
    # 加载 layout_result
    with open("layout_result.pkl", "rb") as f:
        layout_result0 = pickle.load(f)
        layout_result = [row[:5] for row in layout_result0]   # 只保留前5列数据,第一次打开后，不考虑，已设置的功率、剩余能量
        # 给每行新增第 5 列为 0
        for row in layout_result:
                row.append(0)

    # 加载 nodes_first
    with open("nodes_first.pkl", "rb") as f:
        nodes_first = pickle.load(f)

    return layout_result, nodes_first


def save_layout_result(layout_result):
    """
    将更新后的 updated_layout_result 保存到文件中。
    """
    with open("layout_result.pkl", "wb") as f:
        pickle.dump(layout_result, f)
    print("更新后的 layout_result 已保存到文件中。")

def save_interference_info(interference_info):
    """
    将interference_info保存到文件中。
    """
    with open("interference_info.pkl", "wb") as f:
        pickle.dump(interference_info, f)
    print("通信节点的方位信息 interference_info 已保存到文件中。")






# 传播损耗计算公式
L_sight = lambda d: 30 * np.log10(d) + 20 * np.log10(600) + 32.5
L_two_ray = lambda d, h_t, h_r: (
        30 * np.log10(d) - 20 * np.log10(max(h_t, 1e-10)) - 20 * np.log10(max(h_r, 1e-10)) + 120
)


# 定义蜂群算法的参数
num_bees = 10  # 蜜蜂数量
max_iterations = 1000  # 最大迭代次数

def generate_food_source(layout_result):
    """
    生成一个新的食物源（layout_result 信息）
    """
    new_layout_result = [row.copy() for row in layout_result]
    num_selections = 23  # 固定干扰机数量为23
    selected_indices = random.sample(range(23), num_selections)
    for index in selected_indices:
        row = layout_result[index]
        if row[1] == 0:
            # 生成 0 到 1 之间的随机数
            random_num = random.random()
            # 判断是否发生变异,依据变异进行选择
            if random_num < 0.9:
                # 第 2 列为 0，在 1 到 90 之间随机取整数
                row[5] = random.randint(1, 90)
            else:
                row[5] = 90

        elif row[1] == 1:
            # 第 2 列为 1，在 1 到 45 之间随机取整数
            row[5] = random.randint(1, 45)
    return new_layout_result

def test_food_source(communication_result, layout_result):
    """
    测试食物源（layout_result 信息）是否干扰成功
    """
    test_result = test.run_test(communication_result, layout_result)
    return test_result["success"]


# 示例：加载并打印数据
def main_jammer_run():


    layout_result, nodes_first = load_layout_result()
    #print("layout_result:", layout_result)
    #print("nodes_first:", nodes_first)



    # 记录干扰资源调度算法程序开始时间
    start_time = time.time()


    # 处理 nodes_first 数据
    data = []
    # 假设 nodes_first 是二维 numpy 数组
    if isinstance(nodes_first, np.ndarray):
        for row in nodes_first:
            data.append(row)
    else:
        # 如果不是 numpy 数组，按照原来的字符串处理方式
        lines = nodes_first.strip().split('\n')
        for line in lines:
            # 去除方括号和多余的空格
            line = line.replace('[', '').replace(']', '').strip()
            if line:
                data.append(line)

    # 提取所需的列组成新的列表
    communication_result = []
    for row in data:
        # 提取第 1 列、到第9列
        new_row = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9]]
        communication_result.append(new_row)

    #print("communication_result转换后的结果:", communication_result)

    # 初始化蜂群，每个蜜蜂对应一个食物源
    food_sources = [generate_food_source(layout_result) for _ in range(num_bees)]

    # 开始迭代
    for iteration in range(max_iterations):
        # 检查总耗时是否超过 30 秒
        current_time = time.time()
        elapsed_time = current_time - start_time
        if elapsed_time > 30:  # 超过30 秒，停止
            print("总耗时超过 30秒，第一次的搜索，失败。")
            done = True
            break

        else:


            # 让每只蜜蜂测试当前食物源
            for i, food_source in enumerate(food_sources):
                if test_food_source(communication_result, food_source):
                    print("通信干扰成功！")
                    print("本次成功的 layout_result:", food_source)
                    break
                else:
                    # 如果没有干扰成功的食物源，生成新的食物源
                    new_food_sources = []
                    for _ in range(num_bees):
                        new_food_source = generate_food_source(layout_result)
                        new_food_sources.append(new_food_source)
                    food_sources = new_food_sources
                    print("继续生成随机干扰机信息...")
                    continue







    # 遍历 layout_result，检查每一行的第6列
    for row in layout_result:
        if len(row) < 6:  # 如果第6列不存在
            row.append(0)  # 将第6列设置为0
        elif row[5] is None:  # 如果第6列存在但为None
            row[5] = 0  # 将第6列设置为0

    # 计算干扰机的剩余能量
    air_time = land_time = 0.025  # 干扰机工作时间（小时），1.5分钟
    efficiency = 0.95  # 能量转换效率,正常干扰的电量使用上限

    # 遍历 layout_result，计算每个干扰机的剩余能量
    for row in layout_result:

        if row[1] == 0:  # 地面干扰机
            P_landtotal = row[5]  # 地面干扰机的功率
            land_energy = land_time * (4 + P_landtotal) / (efficiency * 24)  # 计算能量消耗
            if len(row) < 7:  # 如果第7列不存在，则扩展列表:
                row.append(0)
                land_energy_initial = 20  # 地面干扰机初始能量（单位：Ah）
            else:
                if row[6] > 0:
                    land_energy_initial = row[6]  # 地面干扰机初始剩余能量（单位：Ah）
                else:
                    print(f"第{row[0]}行的剩余能量值无效：{row[6]}")
                    break
            land_energy_remain = land_energy_initial - land_energy  # 计算剩余能量
            row[6] = round(land_energy_remain, 3)  # 将剩余能量存储在第7列
        elif row[1] == 1:  # 空中干扰机
            P_airtotal = row[5]  # 空中干扰机的功率
            air_energy = air_time * (4 + P_airtotal) / (efficiency * 24)  # 计算能量消耗
            if len(row) < 7:  # 如果第7列不存在，则扩展列表:
                row.append(0)
                air_energy_initial = 12  # 空中干扰机初始能量（单位：Ah）
            else:
                if row[6] > 0:
                    air_energy_initial = row[6]  # 空中干扰机初始剩余能量（单位：Ah）
                else:
                    print(f"第{row[0]}行的剩余能量值无效：{row[6]}")
                    break
            air_energy_remain = air_energy_initial - air_energy  # 计算剩余能量
            row[6] = round(air_energy_remain, 3)  # 将剩余能量存储在第7列


    print("更新后的 layout_result（包含剩余能量）：", layout_result)

    # 保存更新后的 layout_result
    save_layout_result(layout_result)

    # 记录程序结束时间
    end_time = time.time()
    # 计算程序运行时长
    elapsed_time = end_time - start_time

    return layout_result, elapsed_time


if __name__ == "__main__":
    layout_result, elapsed_time = main_jammer_run()
    print(f"程序运行时长: {elapsed_time} 秒")