import pickle
import numpy as np
import time
import test
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import random


# 干扰取链路裕量1倍
Interference_distance = [
    [3, 4.77, 15, 20],
]



def load_layout_result():
    """
    从文件中加载 layout_result 和 communication。
    """
    # 加载 layout_result
    with open("layout_result.pkl", "rb") as f:
        layout_result = pickle.load(f)
        # 将 layout_result 的第 5 列全部设置为 0
        for row in layout_result:
            if len(row) > 4:
                row[5] = 0


    # 加载 communication
    with open("communication.pkl", "rb") as f:
        communication = pickle.load(f)

    return layout_result, communication


def save_layout_result(layout_result):
    """
    将更新后的 updated_layout_result 保存到文件中。
    """
    with open("layout_result.pkl", "wb") as f:
        pickle.dump(layout_result, f)
    print("更新后的 layout_result 已保存到文件中。")


def load_interference_info():
    """
    从文件中加载interference_info。
    """
    # 加载 interference_info
    with open("interference_info.pkl", "rb") as f:
        interference_info = pickle.load(f)

    return interference_info


def save_interference_info(interference_info):
    """
    将interference_info保存到文件中。
    """
    with open("interference_info.pkl", "wb") as f:
        pickle.dump(interference_info, f)
    print("通信节点的方位信息 interference_info 已保存到文件中。")







# 示例：加载并打印数据
def main_jammer_run():


    layout_result, nodes_first = load_layout_result()
    #print("layout_result:", layout_result)
    #print("nodes_first:", nodes_first)


    # 记录程序开始时间
    start_time = time.time()

    air_time = land_time = 0.025  # 干扰机工作时间（小时）
    efficiency = 0.95  # 能量转换效率,正常干扰的电量使用上限

    data = []
    # 假设 nodes_first 是二维列表
    if isinstance(nodes_first, list):
        for row in nodes_first:
            data.append(row)
    # 这里不再需要处理字符串的逻辑，因为 nodes_first 是列表

    # 提取所需的列组成新的列表
    communication_result = []
    for row in data:
        # 提取第 1 列到第 8 列
        new_row = row[:8]  # 简化提取列的操作
        communication_result.append(new_row)

    #print("communication_result转换后的结果:", communication_result)

    # 随机生成要选取的行数，范围是 1 到 28,干扰机数量为28,即随机使用干扰机数量
    while True:
        # 检查总耗时是否超过 3 秒
        current_time = time.time()
        elapsed_time = current_time - start_time
        if elapsed_time > 3:  # 超过 3 秒，停止
            print("总耗时超过 3 秒，停止搜索，未找到可行解。")
            done = True
            break

        num_selections = 28  # 随机搜索，难以求出解，故固定干扰机数量为28，降低了难度
        # num_selections = random.randint(1, 28)
        # 随机选取互不相同的行索引
        selected_indices = random.sample(range(28), num_selections)
        # 遍历选取的行索引
        for index in selected_indices:
            row = layout_result[index]
            if row[1] == 0:
                # 第 2 列为 0，在 1 到 90 之间随机取整数
                row[5] = random.randint(1, 90)
                if row[6] - land_time * (4 + row[5]) / (efficiency * 24) < 0:  # 计算能量消耗
                    row[5] = 0  # 干扰机电量不足，将功率设置为0

            elif row[1] == 1:
                # 第 2 列为 1，在 1 到 45 之间随机取整数
                row[5] = random.randint(1, 45)
                if row[6] - land_time * (4 + row[5]) / (efficiency * 24) < 0:  # 计算能量消耗
                    row[5] = 0  # 干扰机电量不足，将功率设置为0

        # 输出更新后的 layout_result
        #print("本次随机生成的 layout_result:", layout_result)

        # 调用 test.py 的测试函数
        test_result = test.run_test(communication_result, layout_result)

        # 根据测试结果输出信息
        if test_result["success"]:
            print("通信干扰成功！")
            break
        else:
            print("以下通信节点不符合干信比为3的干扰：")
            for warning in test_result["warnings"]:
                print(warning)
            print("继续生成随机干扰机信息...")


    # 遍历 layout_result，检查每一行的第6列
    for row in layout_result:
        if len(row) < 6:  # 如果第6列不存在
            row.append(0)  # 将第6列设置为0
        elif row[5] is None:  # 如果第6列存在但为None
            row[5] = 0  # 将第6列设置为0



    # 计算干扰机的剩余能量


    # 遍历 layout_result，计算每个干扰机的剩余能量
    for row in layout_result:

        if row[1] == 0:  # 地面干扰机
            P_landtotal = row[5]  # 地面干扰机的功率
            land_energy = land_time * (4 + P_landtotal) / (efficiency * 24)  # 计算能量消耗
            if len(row) < 7:  # 如果第7列不存在，则扩展列表:
                row.append(0)
                land_energy_initial = row[6]  # 地面干扰机，上次运行后，剩余的能量（单位：Ah）
            else:
                if row[6] > 0:
                    land_energy_initial = row[6]  # 地面干扰机，上次运行后，剩余的能量（单位：Ah）
                else:
                    print(f"第{row[0]}行的剩余能量值无效：{row[6]}")
                    break
            land_energy_remain = land_energy_initial - land_energy  # 本次运行后，计算剩余能量，默认大于零
            row[6] = round(land_energy_remain, 3)  # 将剩余能量存储在第7列
        elif row[1] == 1:  # 空中干扰机
            P_airtotal = row[5]  # 空中干扰机的功率
            air_energy = air_time * (4 + P_airtotal) / (efficiency * 24)  # 计算能量消耗
            if len(row) < 7:  # 如果第7列不存在，则扩展列表:
                row.append(0)
                air_energy_initial = row[6]  # 空中干扰机上次运行后，剩余的能量（单位：Ah）
            else:
                if row[6] > 0:
                    air_energy_initial = row[6]  # 空中干扰机上次运行后，剩余的能量（单位：Ah）
                else:
                    print(f"第{row[0]}行的剩余能量值无效：{row[6]}")
                    break
            air_energy_remain = air_energy_initial - air_energy  # 计算剩余能量
            if air_energy_remain < 0 and air_energy_remain > -0.02:
                air_energy_remain = 0  # 剩余能量小于0，设置为0，取消计算的误差，使用0.95性能要求外的，小量电量
            row[6] = round(air_energy_remain, 2)  # 将剩余能量存储在第7列


    print("更新后的 layout_result（包含剩余能量）：", layout_result)

    # 保存更新后的 layout_result
    save_layout_result(layout_result)

    # 记录程序结束时间
    end_time = time.time()
    # 计算程序运行时长
    elapsed_time = end_time - start_time

    return layout_result, elapsed_time


if __name__ == "__main__":
    layout_result, elapsed_time = main_jammer_run()
    print(f"程序运行时长: {elapsed_time} 秒")