import pickle
import numpy as np
import time
import test
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import random

# 定义 DQN 神经网络
class DQN(nn.Module):
    def __init__(self, state_size, action_size):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(state_size, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, action_size)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# 定义 DQN 代理
class DQNAgent:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=10000)
        self.gamma = 0.95  # 折扣因子
        self.epsilon = 1.0  # 探索率
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.model = DQN(state_size, action_size)
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001)

    def remember(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))

    def choose_action(self, state):
        if np.random.rand() <= self.epsilon:
            return random.randrange(self.action_size)
        state = torch.FloatTensor(state)
        act_values = self.model(state)
        return torch.argmax(act_values).item()

    def replay(self, batch_size):
        if len(self.memory) < batch_size:
            return
        minibatch = random.sample(self.memory, batch_size)
        states = torch.FloatTensor([t[0] for t in minibatch])
        actions = torch.LongTensor([t[1] for t in minibatch])
        rewards = torch.FloatTensor([t[2] for t in minibatch])
        next_states = torch.FloatTensor([t[3] for t in minibatch])
        dones = torch.FloatTensor([t[4] for t in minibatch])

        current_q = self.model(states).gather(1, actions.unsqueeze(1))
        next_q = self.model(next_states).detach().max(1)[0]
        target_q = rewards + (1 - dones) * self.gamma * next_q

        loss = nn.MSELoss()(current_q.squeeze(), target_q)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

def load_layout_result():
    """
    从文件中加载 layout_result 和 communication。
    """
    with open("layout_result.pkl", "rb") as f:
        layout_result = pickle.load(f)
        for row in layout_result:
            if row[1] == 0:  # 地面干扰机
                row[5] = 90  # 地面干扰机初始功率为90W
            elif row[1] == 1:  # 空中干扰机
                row[5] = 45  # 空中干扰机初始功率为45W

    with open("communication.pkl", "rb") as f:
        communication = pickle.load(f)

    return layout_result, communication

def save_layout_result(layout_result):
    """
    将更新后的 updated_layout_result 保存到文件中。
    """
    with open("layout_result.pkl", "wb") as f:
        pickle.dump(layout_result, f)
    print("更新后的 layout_result 已保存到文件中。")

def main_jammer_run():
    layout_result, communication = load_layout_result()
    print("layout_result:", layout_result)
    print("communication:", communication)

    air_time = land_time = 0.025  # 干扰机工作时间（小时）
    efficiency = 0.95  # 能量转换效率

    # 记录干扰资源调度算法程序开始时间
    start_time = time.time()



    # 初始化 DQN 代理
    state_size = len(layout_result)  # 状态大小为干扰机数量
    action_size = 2  # 动作空间：降低功率或不降低
    agent = DQNAgent(state_size, action_size)

    # 加载训练好的 DQN 模型
    agent.model.load_state_dict(torch.load("dqn_model.pth"))
    agent.model.eval()  # 设置为评估模式
    print("训练好的 DQN 模型已加载。")

    # 继续训练参数
    batch_size = 32
    max_reward = -float('inf')
    best_layout_result = None
    consecutive_failures = 0
    done = False
    iteration = 0  # 迭代次数计数器

    while not done:
        iteration += 1  # 每次迭代增加计数器
        print(f"当前迭代次数: {iteration}")

        # 检查总耗时是否超过 10 秒
        current_time = time.time()
        elapsed_time = current_time - start_time
        if elapsed_time > 3:  # 超过 3 秒，停止训练
            print("总耗时超过3 秒，停止训练。")
            done = True
            break

        state = [row[5] for row in layout_result]  # 当前状态为各干扰机的功率
        action = agent.choose_action(state)  # 选择动作

        # 随机选择一个干扰机，保存原始功率
        selected_jammer = random.randint(0, len(layout_result) - 1)
        original_power = layout_result[selected_jammer][5]

        # 执行动作：降低干扰机功率
        if action == 1:  # 降低功率
            if layout_result[selected_jammer][5] > 0:
                layout_result[selected_jammer][5] -= 5  # 降低该干扰机的功率
                print(f"降低干扰机 {selected_jammer + 1} 的功率，当前功率为 {layout_result[selected_jammer][5]}W")
                if layout_result[selected_jammer][6] - land_time * (4 + layout_result[selected_jammer][5]) / (efficiency * 24)  <  -0.02:# 计算能量消耗
                    original_power = layout_result[selected_jammer][5] = 0  # 干扰机电量不足，将功率设置为0

            else:
                print(f"干扰机 {selected_jammer + 1} 的功率已经为0，无法继续降低")




        # 调用 test.py 的测试函数
        test_result = test.run_test(communication, layout_result)

        # 计算总功率
        total_power = sum([row[5] for row in layout_result])

        # 计算奖励
        if test_result["success"]:
            reward = 1 - total_power / 2250  # 成功干扰，奖励为1 - 所有干扰机的总功率/2250
            if reward > max_reward:
                max_reward = reward
                best_layout_result = [row[:] for row in layout_result]
            # consecutive_failures = 0
        else:
            reward = -1  # 干扰失败，奖励为-1
            layout_result[selected_jammer][5] = original_power  # 取消功率下降
            consecutive_failures += 1

        # 记录经验
        next_state = [row[5] for row in layout_result]
        agent.remember(state, action, reward, next_state, done)

        # 训练 DQN
        agent.replay(batch_size)

        # 检查是否连续多次失败或干扰机能量不足
        if consecutive_failures >= 28:  # 连续10次失败
            done = True
            print("连续28次干扰失败，停止训练。")
        elif all(row[5] == 0 for row in layout_result):  # 所有干扰机功率为0
            done = True
            print("所有干扰机功率为0，停止训练。")

    # 保存最佳干扰机配置
    if best_layout_result:
        layout_result = best_layout_result

    # 保存训练好的 DQN 模型
    torch.save(agent.model.state_dict(), "dqn_model.pth")
    print("训练好的 DQN 模型已保存到 dqn_model.pth 文件中。")

    # 计算干扰机的剩余能量


    for row in layout_result:
        if row[1] == 0:  # 地面干扰机
            P_landtotal = row[5]  # 地面干扰机的功率
            land_energy = land_time * (4 + P_landtotal) / (efficiency * 24)  # 计算能量消耗
            if len(row) < 7:  # 如果第7列不存在，则扩展列表
                row.append(0)
                land_energy_initial = 20  # 地面干扰机初始能量（单位：Ah）
            else:
                land_energy_initial = row[6]  # 地面干扰机初始剩余能量（单位：Ah）
            land_energy_remain = land_energy_initial - land_energy  # 计算剩余能量
            row[6] = round(land_energy_remain, 3)  # 将剩余能量存储在第7列
        elif row[1] == 1:  # 空中干扰机
            P_airtotal = row[5]  # 空中干扰机的功率
            air_energy = air_time * (4 + P_airtotal) / (efficiency * 24)  # 计算能量消耗
            if len(row) < 7:  # 如果第7列不存在，则扩展列表
                row.append(0)
                air_energy_initial = 12  # 空中干扰机初始能量（单位：Ah）
            else:
                air_energy_initial = row[6]  # 空中干扰机初始剩余能量（单位：Ah）
            air_energy_remain = air_energy_initial - air_energy  # 计算剩余能量
            row[6] = round(air_energy_remain, 3)  # 将剩余能量存储在第7列

    print("更新后的 layout_result（包含剩余能量）：", layout_result)

    # 保存更新后的 layout_result
    save_layout_result(layout_result)

    # 记录程序结束时间
    end_time = time.time()
    elapsed_time = end_time - start_time

    return layout_result, elapsed_time

if __name__ == "__main__":
    layout_result, elapsed_time = main_jammer_run()
    print(f"程序运行时长: {elapsed_time} 秒")