import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 设置字体为 Times New Roman 并加粗
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 通信节点数据
nodes_first = [
    [1, 1, 2300, 7600, 2500, 0.42, -93.65],
    [2, 1, 4800, 20000, 2100, 0.87, -93.07],
    [3, 1, 11600, 4700, 2900, 0.15, -95.42],
    [4, 1, 18000, 5300, 2100, 0.63, -92.39],
    [5, 1, 26800, 5700, 2700, 0.29, -89.23],
    [6, 1, 39000, 25800, 2200, 0.76, -94.61],
    [7, 1, 25200, 44200, 2400, 0.51, -94.99],
    [8, 1, 19000, 45000, 2800, 0.94, -94.99],
    [9, 1, 22900, 6700, 2700, 0.38, -89.23],
    [10, 1, 37000, 40800, 2600, 0.05, -95.03],
    [11, 2, 5000, 3000, 5, 0.72, -93.68],
    [12, 2, 6000, 13000, 5, 0.23, -95.95],
    [13, 2, 5500, 23500, 5, 0.56, -89.09],
    [14, 2, 4300, 29000, 5, 0.91, -99.57],
    [15, 2, 5300, 34300, 5, 0.34, -105.39],
    [16, 2, 5900, 40200, 5, 0.67, -105.18],
    [17, 2, 4500, 46400, 5, 0.82, -105.72],
    [18, 2, 9500, 44700, 5, 0.19, -100.46],
    [19, 2, 13000, 39200, 5, 0.45, -98.92],
    [20, 2, 20900, 37000, 5, 0.78, -98.74],
    [21, 2, 30200, 39700, 5, 0.03, -96.19],
    [22, 2, 40900, 39700, 5, 0.61, -91.05],
    [23, 2, 43800, 36800, 5, 0.27, -98.16],
    [24, 2, 38300, 35300, 5, 0.89, -94.39],
    [25, 2, 38700, 29900, 5, 0.52, -90.63],
    [26, 2, 38700, 20400, 5, 0.96, -93.57],
    [27, 2, 37100, 16000, 5, 0.11, -100.87],
    [28, 2, 3800, 10800, 5, 0.64, -89.67],
    [29, 2, 37000, 4800, 5, 0.33, -101.33],
    [30, 2, 31800, 4700, 5, 0.59, -93.41],
]

# 干扰机数据
layout_result = [
    [1, 0, 7046, 7009, 3],
    [2, 0, 6628, 4885, 3],
    [3, 0, 15417, 5542, 3],
    [4, 0, 23758, 4875, 3],
    [5, 0, 28885, 4489, 3],
    [6, 0, 35543, 5104, 3],
    [7, 0, 38280, 16470, 3],
    [8, 1, 36896, 34813, 1280],
    [9, 0, 39060, 40029, 3],
    [10, 0, 42130, 37499, 3],
    [11, 0, 37558, 30770, 3],
    [12, 0, 22012, 44094, 3],
    [13, 0, 10774, 39127, 3],
    [14, 1, 31000, 5200, 1300],
    [15, 0, 18354, 44405, 3],
    [16, 0, 21544, 38240, 3],
    [17, 0, 8117, 44675, 3],
    [18, 0, 5293, 45325, 3],
    [19, 0, 4639, 40791, 3],
    [20, 0, 5687, 35920, 3],
    [21, 0, 5375, 30006, 3],
    [22, 0, 5494, 24641, 3],
    [23, 0, 5963, 20170, 3],
    [24, 0, 5744, 13822, 3],
    [25, 0, 4040, 10052, 3],
    [26, 0, 40040, 25052, 3],
    [27, 0, 30040, 41052, 3],
    [28, 0, 39040, 36052, 3],
    [29, 0, 39040, 20952, 3],
    [30, 0, 29040, 5252, 3],
    [31, 1, 40100, 39000, 800],
    [32, 1, 43000, 36000, 1100],
]

# 创建图形
plt.figure(figsize=(10, 10))

# 绘制通信节点
for node in nodes_first:
    node_id, node_type, x, y, z, _, _, = node
    if node_type == 1:  # 空中通信节点
        plt.scatter(x / 1000, y / 1000, color='green', marker='^', s=100, label='Aerial communication node' if node_type== 1 else "")
    elif node_type == 2:  # 地面通信节点
        plt.scatter(x / 1000, y / 1000, color='blue', marker='^', s=100, label='Ground communication node' if node_type == 2 else "")

# 绘制干扰机
for jammer in layout_result:
    jammer_id, jammer_type, x, y, z, = jammer
    if jammer_type == 0:  # 地面干扰机
        plt.scatter(x / 1000, y / 1000, color='black', marker='*', s=200, label='Ground jammer' if jammer_type == 0 else "")
    elif jammer_type == 1:  # 空中干扰机
        plt.scatter(x / 1000, y / 1000, color='red', marker='*', s=200, label='Aerial jammer' if jammer_type == 1 else "")


# 设置图例
handles, labels = plt.gca().get_legend_handles_labels()
by_label = dict(zip(labels, handles))  # 去重
# 修改图例位置和列数，将图例放置在图表上方中间，取消图例边框
plt.legend(by_label.values(), by_label.keys(), loc='lower center', bbox_to_anchor=(0.5, 0.99), ncol=2, fontsize=20, frameon=False)

# 取消上侧和右侧边框
ax = plt.gca()
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)


# 设置标题和坐标轴标签，增大字体大小
#plt.title("通信节点和干扰机分布图", fontsize=20)
#plt.xlabel("X 坐标", fontsize=16)
#plt.ylabel("Y 坐标", fontsize=16)

# 设置坐标轴刻度和标签
plt.xticks([10, 20, 30, 40, 50], fontsize=25)
plt.yticks([10, 20, 30, 40, 50], fontsize=25)

# 设置坐标轴标签
plt.xlabel(" x-coordinate (km)", fontsize=25)
plt.ylabel(" y-coordinate (km)", fontsize=25)


# 显示图形
plt.grid(False)
plt.show()




