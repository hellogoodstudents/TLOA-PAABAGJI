import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 设置字体为 Times New Roman 并加粗
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 通信节点数据
nodes_first = [
    [1, 1, 41300, 19600, 2500, 0.18, -100.97],
    [2, 1, 27800, 20000, 2100, 0.87, -98.86],
    [3, 1, 21600, 4700, 2900, 0.72, -93.72],
    [4, 1, 8700, 19300, 2100, 0.21, -97.86],
    [5, 1, 30000, 11800, 2200, 0.35, -98.18],
    [6, 1, 30200, 44200, 2400, 0.59, -102.41],
    [7, 1, 19000, 28000, 2800, 0.71, -96.42],
    [8, 1, 18900, 9700, 2700, 0.34, -93.72],
    [9, 1, 30000, 29800, 2600, 0.62, -98.49],
    [10, 2, 13700, 33400, 5, 0.12, -97.78],
    [11, 2, 36800, 38600, 5, 0.35, -99.18],
    [12, 2, 33700, 24000, 5, 0.87, -96.58],
    [13, 2, 24500, 38400, 5, 0.55, -98.43],
    [14, 2, 12900, 23000, 5, 0.25, -93.88],
    [15, 2, 33900, 19700, 5, 0.65, -94.88],
    [16, 2, 24800, 32800, 5, 0.85, -95.05],
    [17, 2, 24300, 12300, 5, 0.05, -94.2],
    [18, 2, 19700, 44900, 5, 0.25, -101.58],
    [19, 2, 35700, 29400, 5, 0.45, -94.51],
    [20, 2, 35100, 16000, 5, 0.65, -95.86],
    [21, 2, 23000, 25800, 5, 0.85, -92.44],
    [22, 2, 14000, 14800, 5, 0.05, -96.41],
]

# 干扰机数据
layout_result = [
    [1, 0, 17542, 27205, 3],
    [2, 0, 24858, 11009, 3],
    [3, 0, 40433, 20135, 3],
    [4, 0, 29537, 10467, 3],
    [5, 0, 20436, 4456, 3],
    [6, 0, 29447, 30732, 3],
    [7, 1, 9729, 20245, 1246],
    [8, 1, 21529, 40113, 1000],
    [9, 1, 26994, 20379, 1159],
    [10, 0, 35573, 16765, 3],
    [11, 1, 17803, 24661, 1000],
    [12, 0, 12816, 14057, 3],
    [13, 0, 25198, 32156, 3],
    [14, 0, 29479, 45128, 3],
    [15, 0, 34144, 23527, 3],
    [16, 0, 36168, 27938, 3],
    [17, 1, 25221, 36183, 1400],
    [18, 1, 20309, 9309, 519],
    [19, 0, 20579, 44471, 3],
    [20, 0, 23372, 26319, 3],
    [21, 0, 38089, 37672, 3],
    [22, 0, 12219, 32118, 3],
    [23, 1, 34617, 20857, 800],
    [24, 0, 12214, 24327, 3],
]

# 创建图形
plt.figure(figsize=(10, 10))

# 绘制通信节点
for node in nodes_first:
    node_id, node_type, x, y, z, _, _, = node
    if node_type == 1:  # 空中通信节点
        plt.scatter(x / 1000, y / 1000, color='green', marker='^', s=100, label='Aerial communication node' if node_type== 1 else "")
    elif node_type == 2:  # 地面通信节点
        plt.scatter(x / 1000, y / 1000, color='blue', marker='^', s=100, label='Ground communication node' if node_type == 2 else "")

# 绘制干扰机
for jammer in layout_result:
    jammer_id, jammer_type, x, y, z, = jammer
    if jammer_type == 0:  # 地面干扰机
        plt.scatter(x / 1000, y / 1000, color='black', marker='*', s=200, label='Ground jammer' if jammer_type == 0 else "")
    elif jammer_type == 1:  # 空中干扰机
        plt.scatter(x / 1000, y / 1000, color='red', marker='*', s=200, label='Aerial jammer' if jammer_type == 1 else "")


# 设置图例
handles, labels = plt.gca().get_legend_handles_labels()
by_label = dict(zip(labels, handles))  # 去重
# 修改图例位置和列数，将图例放置在图表上方中间，取消图例边框
plt.legend(by_label.values(), by_label.keys(), loc='lower center', bbox_to_anchor=(0.5, 0.99), ncol=2, fontsize=20, frameon=False)

# 取消上侧和右侧边框
ax = plt.gca()
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)


# 设置标题和坐标轴标签，增大字体大小
#plt.title("通信节点和干扰机分布图", fontsize=20)
#plt.xlabel("X 坐标", fontsize=16)
#plt.ylabel("Y 坐标", fontsize=16)

# 设置坐标轴刻度和标签
plt.xticks([10, 20, 30, 40, 50], fontsize=25)
plt.yticks([10, 20, 30, 40, 50], fontsize=25)

# 设置坐标轴标签
plt.xlabel(" x-coordinate (km)", fontsize=25)
plt.ylabel(" y-coordinate (km)", fontsize=25)


# 显示图形
plt.grid(False)
plt.show()




