import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 设置字体为 Times New Roman 并加粗
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 通信节点数据
nodes_first = [
    [1, 1, 42800, 6500, 2000, 0.71, -94.03],
    [2, 1, 5800, 45800, 2100, 0.2, -97.87],
    [3, 1, 4600, 27300, 3000, 0.96, -100.57],
    [4, 1, 32100, 18600, 2200, 0.67, -105.13],
    [5, 1, 17200, 38400, 2000, 0.63, -99.87],
    [6, 2, 36700, 45800, 5, 0.55, -103.34],
    [7, 2, 46300, 4600, 5, 0.9, -90.05],
    [8, 2, 11000, 35900, 5, 0.25, -95.89],
    [9, 2, 44600, 33500, 5, 0.18, -103.49],
    [10, 2, 9000, 41200, 5, 0.42, -93.89],
    [11, 2, 26200, 5800, 5, 0.56, -101.58],
    [12, 2, 3500, 10000, 5, 0.48, -107.94],
    [13, 2, 29200, 500, 5, 0.78, -101.58],
    [14, 2, 21600, 12600, 5, 0.38, -103.27],
    [15, 2, 38600, 29800, 5, 0.85, -103.49],
    [16, 2, 15200, 17900, 5, 0.79, -104.61],
    [17, 2, 10400, 23900, 5, 0.74, -96.59],
    [18, 2, 46900, 17400, 5, 0.06, -102.76],
    [19, 2, 29800, 44800, 5, 0.09, -103.34],
    [20, 2, 23200, 23600, 5, 0.89, -101.15],
]

# 干扰机数据
layout_result = [
    [1, 0, 42477, 8065, 3],
    [2, 0, 44438, 32062, 3],
    [3, 0, 4020, 26808, 3],
    [4, 0, 22607, 24095, 3],
    [5, 0, 36789, 45253, 3],
    [6, 0, 28452, 1172, 3],
    [7, 0, 9741, 35353, 3],
    [8, 0, 7296, 45367, 3],
    [9, 0, 10941, 25200, 3],
    [10, 0, 40060, 29823, 3],
    [11, 1, 25424, 5581, 1300],
    [12, 0, 15887, 19078, 3],
    [13, 0, 16810, 37403, 3],
    [14, 1, 9355, 41961, 1200],
    [15, 0, 31620, 17562, 3],
    [16, 0, 28781, 45530, 3],
    [17, 0, 21217, 11331, 3],
    [18, 0, 4318, 10970, 3],
    [19, 0, 47780, 16447, 3],
    [20, 1, 42361, 5021, 1300],
    [21, 0, 43572, 6112, 3],
    [22, 1, 43678, 4116, 1129],
    [23, 1, 18678, 21116, 1129],
    [24, 0, 9217, 41331, 3],
    [25, 0, 7017, 24331, 3],
    [26, 0, 19017, 18331, 3],
    [27, 0, 42017, 30331, 3],
    [28, 1, 34417, 44331, 1003],
]

# 创建图形
plt.figure(figsize=(10, 10))

# 绘制通信节点
for node in nodes_first:
    node_id, node_type, x, y, z, _, _, = node
    if node_type == 1:  # 空中通信节点
        plt.scatter(x / 1000, y / 1000, color='green', marker='^', s=100, label='Aerial communication node' if node_type== 1 else "")
    elif node_type == 2:  # 地面通信节点
        plt.scatter(x / 1000, y / 1000, color='blue', marker='^', s=100, label='Ground communication node' if node_type == 2 else "")

# 绘制干扰机
for jammer in layout_result:
    jammer_id, jammer_type, x, y, z, = jammer
    if jammer_type == 0:  # 地面干扰机
        plt.scatter(x / 1000, y / 1000, color='black', marker='*', s=200, label='Ground jammer' if jammer_type == 0 else "")
    elif jammer_type == 1:  # 空中干扰机
        plt.scatter(x / 1000, y / 1000, color='red', marker='*', s=200, label='Aerial jammer' if jammer_type == 1 else "")


# 设置图例
handles, labels = plt.gca().get_legend_handles_labels()
by_label = dict(zip(labels, handles))  # 去重
# 修改图例位置和列数，将图例放置在图表上方中间，取消图例边框
plt.legend(by_label.values(), by_label.keys(), loc='lower center', bbox_to_anchor=(0.5, 0.99), ncol=2, fontsize=20, frameon=False)

# 取消上侧和右侧边框
ax = plt.gca()
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)


# 设置标题和坐标轴标签，增大字体大小
#plt.title("通信节点和干扰机分布图", fontsize=20)
#plt.xlabel("X 坐标", fontsize=16)
#plt.ylabel("Y 坐标", fontsize=16)

# 设置坐标轴刻度和标签
plt.xticks([10, 20, 30, 40, 50], fontsize=25)
plt.yticks([10, 20, 30, 40, 50], fontsize=25)

# 设置坐标轴标签
plt.xlabel(" x-coordinate (km)", fontsize=25)
plt.ylabel(" y-coordinate (km)", fontsize=25)


# 显示图形
plt.grid(False)
plt.show()




