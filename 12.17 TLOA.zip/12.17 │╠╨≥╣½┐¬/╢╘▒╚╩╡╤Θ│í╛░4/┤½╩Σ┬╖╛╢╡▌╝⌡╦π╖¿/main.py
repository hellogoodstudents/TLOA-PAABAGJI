from generate_nodes import generate_nodes
from modify_communication_nodes import modify_communication_nodes
import pickle
import numpy as np
import time
import test
import jammer_run
import jammer_first_run
# 导入 test.py 模块
#1.运行main，将生成的通信节点信息和干扰机信息（无剩余功率）保存到文件中（layout_result 和 nodes_first），表示未更新的干扰机信息。
# 2.运行jammer_first_run，第一次计算干扰机的剩余功率，将更新后的 干扰机信息 保存到文件updated_layout_result中
#3.回到main，将updated_layout_result覆盖在layout_result中。
# 4.运行main，启动test，以新的干扰机信息和通信节点信息（layout_result和communication），进行测试，判断干扰是否符合干信比为3的要求。


def save_layout_result(layout_result, nodes_first):
    """
    将 layout_result 和 nodes_first 保存到文件中。
    """
    # 保存 layout_result
    with open("layout_result.pkl", "wb") as f:  #含干扰机剩余能量
        pickle.dump(layout_result, f)

    # 保存 nodes_first
    with open("nodes_first.pkl", "wb") as f:
        pickle.dump(nodes_first, f)

    print("layout_result 和 nodes_first 已保存到文件中。")



def load_layout_result():
    """
    从文件中加载更新后的 updated_layout_result。
    """
    with open("layout_result.pkl", "rb") as f:
        layout_result = pickle.load(f)
    return layout_result

def load_nodes_first():
    """
    从文件中加载更新后的 nodes_first。
    """
    with open("nodes_first.pkl", "rb") as f:
        nodes_first = pickle.load(f)
    return nodes_first


def main():
    nodes_first = [
        [1, 1, 2300, 7600, 2500, 0.42, -93.65],
        [2, 1, 4800, 20000, 2100, 0.87, -93.07],
        [3, 1, 11600, 4700, 2900, 0.15, -95.42],
        [4, 1, 18000, 5300, 2100, 0.63, -92.39],
        [5, 1, 26800, 5700, 2700, 0.29, -89.23],
        [6, 1, 39000, 25800, 2200, 0.76, -94.61],
        [7, 1, 25200, 44200, 2400, 0.51, -94.99],
        [8, 1, 19000, 45000, 2800, 0.94, -94.99],
        [9, 1, 22900, 6700, 2700, 0.38, -89.23],
        [10, 1, 37000, 40800, 2600, 0.05, -95.03],
        [11, 2, 5000, 3000, 5, 0.72, -93.68],
        [12, 2, 6000, 13000, 5, 0.23, -95.95],
        [13, 2, 5500, 23500, 5, 0.56, -89.09],
        [14, 2, 4300, 29000, 5, 0.91, -99.57],
        [15, 2, 5300, 34300, 5, 0.34, -105.39],
        [16, 2, 5900, 40200, 5, 0.67, -105.18],
        [17, 2, 4500, 46400, 5, 0.82, -105.72],
        [18, 2, 9500, 44700, 5, 0.19, -100.46],
        [19, 2, 13000, 39200, 5, 0.45, -98.92],
        [20, 2, 20900, 37000, 5, 0.78, -98.74],
        [21, 2, 30200, 39700, 5, 0.03, -96.19],
        [22, 2, 40900, 39700, 5, 0.61, -91.05],
        [23, 2, 43800, 36800, 5, 0.27, -98.16],
        [24, 2, 38300, 35300, 5, 0.89, -94.39],
        [25, 2, 38700, 29900, 5, 0.52, -90.63],
        [26, 2, 38700, 20400, 5, 0.96, -93.57],
        [27, 2, 37100, 16000, 5, 0.11, -100.87],
        [28, 2, 3800, 10800, 5, 0.64, -89.67],
        [29, 2, 37000, 4800, 5, 0.33, -101.33],
        [30, 2, 31800, 4700, 5, 0.59, -93.41],
    ]

    # 将第7列内容全部换算成1，表示频段为1
    for node in nodes_first:
        node[6] = 1  # 第7列表示频段，设置为1

    # 调用 generate_nodes 函数，生成初始的通信节点信息
    nodes_first = generate_nodes(nodes_first)


    # 定义 layout_result，干扰机位置
    layout_result = [
        [1, 0, 7046, 7009, 3],
        [2, 0, 6628, 4885, 3],
        [3, 0, 15417, 5542, 3],
        [4, 0, 23758, 4875, 3],
        [5, 0, 28885, 4489, 3],
        [6, 0, 35543, 5104, 3],
        [7, 0, 38280, 16470, 3],
        [8, 1, 36896, 34813, 1280],
        [9, 0, 39060, 40029, 3],
        [10, 0, 42130, 37499, 3],
        [11, 0, 37558, 30770, 3],
        [12, 0, 22012, 44094, 3],
        [13, 0, 10774, 39127, 3],
        [14, 1, 31000, 5200, 1300],
        [15, 0, 18354, 44405, 3],
        [16, 0, 21544, 38240, 3],
        [17, 0, 8117, 44675, 3],
        [18, 0, 5293, 45325, 3],
        [19, 0, 4639, 40791, 3],
        [20, 0, 5687, 35920, 3],
        [21, 0, 5375, 30006, 3],
        [22, 0, 5494, 24641, 3],
        [23, 0, 5963, 20170, 3],
        [24, 0, 5744, 13822, 3],
        [25, 0, 4040, 10052, 3],
        [26, 0, 40040, 25052, 3],
        [27, 0, 30040, 41052, 3],
        [28, 0, 39040, 36052, 3],
        [29, 0, 39040, 20952, 3],
        [30, 0, 29040, 5252, 3],
        [31, 1, 40100, 39000, 800],
        [32, 1, 43000, 36000, 1100],
    ]

    # 保存 layout_result 和 nodes_first 到文件
    save_layout_result(layout_result, nodes_first)

    # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

    layout_result, elapsed_time = jammer_first_run.main_jammer_run()


    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中

    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中
    with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
        f.write(f"1次循环通信干扰决策\n")
        f.write(f"程序运行时长: {elapsed_time} 秒\n")
        f.write("layout_result数据:\n")
        for item in layout_result:
            f.write(f"{item}\n")

    # 加载第一次干扰更新后的 layout_result，干扰机序号、类型、x、y、z、功率w、剩余能量AH
    updated_layout_result = load_layout_result()
    #print("第一次更新后的 干扰机layout_result：", updated_layout_result,)



    #  将更新后的 updated_layout_result 保存到文件中 保存到 jammer.pkl 供 test.py 使用  ,不含干扰机剩余能量



    # 删除第 7、8 列数据（索引为 6、7）,对初始的通信节点nodes_first，处理，
    #communication2 含序号、类型、x坐标、y坐标、z坐标、天线高度、威慑度、该节点的最低发信功率（dBW）、该节点的最大收信功率（dBW）
    columns_to_delete = [6, 7]
    communication2 = np.delete(nodes_first, columns_to_delete, axis=1)
    # 将 communication2 转换为列表
    communication2 = communication2.tolist()

    print('communication2:')
    for row in communication2:
        print(row)

    # 将 communication2 保存到 communication.pkl 供 test.py 使用
    with open("communication.pkl", "wb") as f:
        pickle.dump(communication2, f)


    # 调用 test.py 的测试函数
    test_result = test.run_test(communication2, updated_layout_result)

    # 根据测试结果输出信息
    if test_result["success"]:
        print("通信干扰成功！")
    else:
        print("以下通信节点不符合干信比为3的干扰：")
        for warning in test_result["warnings"]:
            print(warning)


    # 依据成功干扰后的communication，生成新的通信信息，读取含剩余能量的layout_result,得到新的干扰机信息layout_result
    i = 2  # 初始化循环次数
    while True:
        communication = modify_communication_nodes()
        print('功率调整后的通信方', communication)  # 序号、类型、x坐标、y坐标、z坐标、天线高度、威慑度、该节点的最低发信功率（dBW）、该节点的最大收信功率（dBW）

        # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

        layout_result, elapsed_time = jammer_run.main_jammer_run()




        # 调用 test.py 的测试函数
        test_result = test.run_test(communication, layout_result)

        # 根据测试结果输出信息
        if test_result["success"]:
            print(f"第{i}次通信干扰成功！")
            # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,有用的次数减1
            with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                f.write(f"{i}次循环通信干扰决策\n")
                f.write(f"程序运行时长: {elapsed_time} 秒\n")
                f.write("layout_result数据:\n")
                for item in layout_result:
                    f.write(f"{item}\n")

            i += 1  # 循环次数加1

        else:
            print(f"第{i}次通信干扰失败！")
            print("以下通信节点达不到不符合干信比为3的干扰：")
            for warning in test_result["warnings"]:
                print(warning)

            # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,保留最后失败的干扰数据，有用的次数减1
            with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                f.write(f"{i}次循环通信干扰决策\n")
                f.write(f"程序运行时长: {elapsed_time} 秒\n")
                f.write("layout_result数据:\n")
                for item in layout_result:
                    f.write(f"{item}\n")




            break  # 通信干扰失败，停止循环


    layout_result = load_layout_result()
    print("干扰失败后，最后更新后的 干扰机layout_result：", layout_result)


if __name__ == '__main__':
    for _ in range(1):  #程序运行30次
        main()