from generate_nodes import generate_nodes
from modify_communication_nodes import modify_communication_nodes
import pickle
import numpy as np
import time
import test
import jammer_run
import jammer_first_run
# 导入 test.py 模块
#1.运行main，将生成的通信节点信息和干扰机信息（无剩余功率）保存到文件中（layout_result 和 nodes_first），表示未更新的干扰机信息。
# 2.运行jammer_first_run，第一次计算干扰机的剩余功率，将更新后的 干扰机信息 保存到文件updated_layout_result中
#3.回到main，将updated_layout_result覆盖在layout_result中。
# 4.运行main，启动test，以新的干扰机信息和通信节点信息（layout_result和communication），进行测试，判断干扰是否符合干信比为3的要求。


def save_layout_result(layout_result, nodes_first):
    """
    将 layout_result 和 nodes_first 保存到文件中。
    """
    # 保存 layout_result
    with open("layout_result.pkl", "wb") as f:  #含干扰机剩余能量
        pickle.dump(layout_result, f)

    # 保存 nodes_first
    with open("nodes_first.pkl", "wb") as f:
        pickle.dump(nodes_first, f)

    print("layout_result 和 nodes_first 已保存到文件中。")



def load_layout_result():
    """
    从文件中加载更新后的 updated_layout_result。
    """
    with open("layout_result.pkl", "rb") as f:
        layout_result = pickle.load(f)
    return layout_result

def load_nodes_first():
    """
    从文件中加载更新后的 nodes_first。
    """
    with open("nodes_first.pkl", "rb") as f:
        nodes_first = pickle.load(f)
    return nodes_first


def main():
    nodes_first = [
        [1, 2, 42800, 6500, 5, 0.71, -89.24],
        [2, 2, 5800, 45800, 5, 0.2, -93.54],
        [3, 2, 4600, 27300, 5, 0.96, -95.58],
        [4, 2, 32100, 18600, 5, 0.67, -100.94],
        [5, 2, 17200, 38400, 5, 0.63, -95.61],
        [6, 1, 36700, 45800, 1800, 0.55, -96.42],
        [7, 1, 46300, 4600, 1300, 0.9, -93.22],
        [8, 1, 11000, 35900, 1400, 0.25, -93.69],
        [9, 1, 44600, 33500, 1500, 0.18, -96.53],
        [10, 1, 9000, 41200, 1600, 0.42, -93.69],
        [11, 1, 26200, 5800, 1300, 0.56, -94.63],
        [12, 1, 3500, 10000, 1400, 0.48, -105.58],
        [13, 1, 29200, 500, 1500, 0.78, -94.63],
        [14, 1, 21600, 12600, 1700, 0.38, -98.53],
        [15, 1, 38600, 29800, 1600, 0.85, -96.53],
        [16, 1, 15200, 17900, 1700, 0.79, -97.69],
        [17, 1, 10400, 23900, 1100, 0.74, -97.69],
        [18, 1, 46900, 17400, 1200, 0.06, -104.31],
        [19, 1, 29800, 44800, 1300, 0.09, -96.42],
        [20, 1, 23200, 23600, 1200, 0.89, -100.87],
    ]

    # 将第7列内容全部换算成1，表示频段为1
    for node in nodes_first:
        node[6] = 1  # 第7列表示频段，设置为1

    # 调用 generate_nodes 函数，生成初始的通信节点信息
    nodes_first = generate_nodes(nodes_first)


    # 定义 layout_result，干扰机位置
    layout_result = [
        [1, 0, 45411, 3073, 3],
        [2, 0, 40148, 28784, 3],
        [3, 1, 5444, 7687, 1819],
        [4, 0, 37601, 47357, 3],
        [5, 0, 27096, 5219, 3],
        [6, 0, 5221, 45041, 3],
        [7, 0, 29570, 0, 3],
        [8, 0, 14702, 18333, 3],
        [9, 0, 23887, 25119, 3],
        [10, 0, 29295, 43702, 3],
        [11, 0, 10416, 35278, 3],
        [12, 0, 30204, 19230, 3],
        [13, 0, 43573, 32837, 3],
        [14, 0, 48816, 15859, 3],
        [15, 0, 22252, 13016, 3],
        [16, 0, 9996, 25153, 3],
        [17, 0, 15226, 38995, 3],
        [18, 1, 43154, 7709, 1152],
        [19, 0, 3937, 28022, 3],
        [20, 0, 7343, 40478, 3],
        [21, 0, 9932, 41857, 3],
        [22, 0, 9843, 39410, 3],
        [23, 0, 8149, 39795, 3],
    ]

    # 保存 layout_result 和 nodes_first 到文件
    save_layout_result(layout_result, nodes_first)

    # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

    layout_result, elapsed_time = jammer_first_run.main_jammer_run()


    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中

    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中
    with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
        f.write(f"1次循环通信干扰决策\n")
        f.write(f"程序运行时长: {elapsed_time} 秒\n")
        f.write("layout_result数据:\n")
        for item in layout_result:
            f.write(f"{item}\n")

    # 加载第一次干扰更新后的 layout_result，干扰机序号、类型、x、y、z、功率w、剩余能量AH
    updated_layout_result = load_layout_result()
    #print("第一次更新后的 干扰机layout_result：", updated_layout_result,)



    #  将更新后的 updated_layout_result 保存到文件中 保存到 jammer.pkl 供 test.py 使用  ,不含干扰机剩余能量



    # 删除第 7、8 列数据（索引为 6、7）,对初始的通信节点nodes_first，处理，
    #communication2 含序号、类型、x坐标、y坐标、z坐标、天线高度、威慑度、该节点的最低发信功率（dBW）、该节点的最大收信功率（dBW）
    columns_to_delete = [6, 7]
    communication2 = np.delete(nodes_first, columns_to_delete, axis=1)
    # 将 communication2 转换为列表
    communication2 = communication2.tolist()

    print('communication2:')
    for row in communication2:
        print(row)

    # 将 communication2 保存到 communication.pkl 供 test.py 使用
    with open("communication.pkl", "wb") as f:
        pickle.dump(communication2, f)


    # 调用 test.py 的测试函数
    test_result = test.run_test(communication2, updated_layout_result)

    # 根据测试结果输出信息
    if test_result["success"]:
        print("通信干扰成功！")
    else:
        print("以下通信节点不符合干信比为3的干扰：")
        for warning in test_result["warnings"]:
            print(warning)


    # 依据成功干扰后的communication，生成新的通信信息，读取含剩余能量的layout_result,得到新的干扰机信息layout_result
    i = 2  # 初始化循环次数
    while True:
        communication = modify_communication_nodes()
        print('功率调整后的通信方', communication)  # 序号、类型、x坐标、y坐标、z坐标、天线高度、威慑度、该节点的最低发信功率（dBW）、该节点的最大收信功率（dBW）

        # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

        layout_result, elapsed_time = jammer_run.main_jammer_run()




        # 调用 test.py 的测试函数
        test_result = test.run_test(communication, layout_result)

        # 根据测试结果输出信息
        if test_result["success"]:
            print(f"第{i}次通信干扰成功！")
            # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,有用的次数减1
            with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                f.write(f"{i}次循环通信干扰决策\n")
                f.write(f"程序运行时长: {elapsed_time} 秒\n")
                f.write("layout_result数据:\n")
                for item in layout_result:
                    f.write(f"{item}\n")

            i += 1  # 循环次数加1

        else:
            print(f"第{i}次通信干扰失败！")
            print("以下通信节点达不到不符合干信比为3的干扰：")
            for warning in test_result["warnings"]:
                print(warning)

            # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,保留最后失败的干扰数据，有用的次数减1
            with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                f.write(f"{i}次循环通信干扰决策\n")
                f.write(f"程序运行时长: {elapsed_time} 秒\n")
                f.write("layout_result数据:\n")
                for item in layout_result:
                    f.write(f"{item}\n")




            break  # 通信干扰失败，停止循环


    layout_result = load_layout_result()
    print("干扰失败后，最后更新后的 干扰机layout_result：", layout_result)


if __name__ == '__main__':
    for _ in range(1):  #程序运行30次
        main()