from generate_nodes import generate_nodes
from modify_communication_nodes import modify_communication_nodes
import pickle
import numpy as np
import time
import test
import jammer_run
import jammer_first_run
# 导入 test.py 模块
#1.运行main，将生成的通信节点信息和干扰机信息（无剩余功率）保存到文件中（layout_result 和 nodes_first），表示未更新的干扰机信息。
# 2.运行jammer_first_run，第一次计算干扰机的剩余功率，将更新后的 干扰机信息 保存到文件updated_layout_result中
#3.回到main，将updated_layout_result覆盖在layout_result中。
# 4.运行main，启动test，以新的干扰机信息和通信节点信息（layout_result和communication），进行测试，判断干扰是否符合干信比为3的要求。


def save_layout_result(layout_result, nodes_first):
    """
    将 layout_result 和 nodes_first 保存到文件中。
    """
    # 保存 layout_result
    with open("layout_result.pkl", "wb") as f:  #含干扰机剩余能量
        pickle.dump(layout_result, f)

    # 保存 nodes_first
    with open("nodes_first.pkl", "wb") as f:
        pickle.dump(nodes_first, f)

    print("layout_result 和 nodes_first 已保存到文件中。")



def load_layout_result():
    """
    从文件中加载更新后的 updated_layout_result。
    """
    with open("layout_result.pkl", "rb") as f:
        layout_result = pickle.load(f)
    return layout_result

def load_nodes_first():
    """
    从文件中加载更新后的 nodes_first。
    """
    with open("nodes_first.pkl", "rb") as f:
        nodes_first = pickle.load(f)
    return nodes_first


def main():
    nodes_first = [
        [1, 1, 41300, 19600, 2500, 0.18, -100.97],
        [2, 1, 27800, 20000, 2100, 0.87, -98.86],
        [3, 1, 21600, 4700, 2900, 0.72, -93.72],
        [4, 1, 8700, 19300, 2100, 0.21, -97.86],
        [5, 1, 30000, 11800, 2200, 0.35, -98.18],
        [6, 1, 30200, 44200, 2400, 0.59, -102.41],
        [7, 1, 19000, 28000, 2800, 0.71, -96.42],
        [8, 1, 18900, 9700, 2700, 0.34, -93.72],
        [9, 1, 30000, 29800, 2600, 0.62, -98.49],
        [10, 2, 13700, 33400, 5, 0.12, -97.78],
        [11, 2, 36800, 38600, 5, 0.35, -99.18],
        [12, 2, 33700, 24000, 5, 0.87, -96.58],
        [13, 2, 24500, 38400, 5, 0.55, -98.43],
        [14, 2, 12900, 23000, 5, 0.25, -93.88],
        [15, 2, 33900, 19700, 5, 0.65, -94.88],
        [16, 2, 24800, 32800, 5, 0.85, -95.05],
        [17, 2, 24300, 12300, 5, 0.05, -94.2],
        [18, 2, 19700, 44900, 5, 0.25, -101.58],
        [19, 2, 35700, 29400, 5, 0.45, -94.51],
        [20, 2, 35100, 16000, 5, 0.65, -95.86],
        [21, 2, 23000, 25800, 5, 0.85, -92.44],
        [22, 2, 14000, 14800, 5, 0.05, -96.41],
    ]

    # 将第7列内容全部换算成1，表示频段为1
    for node in nodes_first:
        node[6] = 1  # 第7列表示频段，设置为1

    # 调用 generate_nodes 函数，生成初始的通信节点信息
    nodes_first = generate_nodes(nodes_first)


    # 定义 layout_result，干扰机位置
    layout_result = [
        [1, 0, 17542, 27205, 3],
        [2, 0, 24858, 11009, 3],
        [3, 0, 40433, 20135, 3],
        [4, 0, 29537, 10467, 3],
        [5, 0, 20436, 4456, 3],
        [6, 0, 29447, 30732, 3],
        [7, 1, 9729, 20245, 1246],
        [8, 1, 21529, 40113, 1000],
        [9, 1, 26994, 20379, 1159],
        [10, 0, 35573, 16765, 3],
        [11, 1, 17803, 24661, 1000],
        [12, 0, 12816, 14057, 3],
        [13, 0, 25198, 32156, 3],
        [14, 0, 29479, 45128, 3],
        [15, 0, 34144, 23527, 3],
        [16, 0, 36168, 27938, 3],
        [17, 1, 25221, 36183, 1400],
        [18, 1, 20309, 9309, 519],
        [19, 0, 20579, 44471, 3],
        [20, 0, 23372, 26319, 3],
        [21, 0, 38089, 37672, 3],
        [22, 0, 12219, 32118, 3],
        [23, 1, 34617, 20857, 800],
        [24, 0, 12214, 24327, 3],
    ]

    # 保存 layout_result 和 nodes_first 到文件
    save_layout_result(layout_result, nodes_first)

    # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

    layout_result, elapsed_time = jammer_first_run.main_jammer_run()


    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中

    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中
    with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
        f.write(f"1次循环通信干扰决策\n")
        f.write(f"程序运行时长: {elapsed_time} 秒\n")
        f.write("layout_result数据:\n")
        for item in layout_result:
            f.write(f"{item}\n")

    # 加载第一次干扰更新后的 layout_result，干扰机序号、类型、x、y、z、功率w、剩余能量AH
    updated_layout_result = load_layout_result()
    #print("第一次更新后的 干扰机layout_result：", updated_layout_result,)



    #  将更新后的 updated_layout_result 保存到文件中 保存到 jammer.pkl 供 test.py 使用  ,不含干扰机剩余能量



    # 删除第 7、8 列数据（索引为 6、7）,对初始的通信节点nodes_first，处理，
    #communication2 含序号、类型、x坐标、y坐标、z坐标、天线高度、威慑度、该节点的最低发信功率（dBW）、该节点的最大收信功率（dBW）
    columns_to_delete = [6, 7]
    communication2 = np.delete(nodes_first, columns_to_delete, axis=1)
    # 将 communication2 转换为列表
    communication2 = communication2.tolist()

    print('communication2:')
    for row in communication2:
        print(row)

    # 将 communication2 保存到 communication.pkl 供 test.py 使用
    with open("communication.pkl", "wb") as f:
        pickle.dump(communication2, f)


    # 调用 test.py 的测试函数
    test_result = test.run_test(communication2, updated_layout_result)

    # 根据测试结果输出信息
    if test_result["success"]:
        print("通信干扰成功！")
    else:
        print("以下通信节点不符合干信比为3的干扰：")
        for warning in test_result["warnings"]:
            print(warning)


    # 依据成功干扰后的communication，生成新的通信信息，读取含剩余能量的layout_result,得到新的干扰机信息layout_result
    i = 2  # 初始化循环次数
    while True:
        communication = modify_communication_nodes()
        print('功率调整后的通信方', communication)  # 序号、类型、x坐标、y坐标、z坐标、天线高度、威慑度、该节点的最低发信功率（dBW）、该节点的最大收信功率（dBW）

        # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

        layout_result, elapsed_time = jammer_run.main_jammer_run()




        # 调用 test.py 的测试函数
        test_result = test.run_test(communication, layout_result)

        # 根据测试结果输出信息
        if test_result["success"]:
            print(f"第{i}次通信干扰成功！")
            # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,有用的次数减1
            with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                f.write(f"{i}次循环通信干扰决策\n")
                f.write(f"程序运行时长: {elapsed_time} 秒\n")
                f.write("layout_result数据:\n")
                for item in layout_result:
                    f.write(f"{item}\n")

            i += 1  # 循环次数加1

        else:
            print(f"第{i}次通信干扰失败！")
            print("以下通信节点达不到不符合干信比为3的干扰：")
            for warning in test_result["warnings"]:
                print(warning)

            # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,保留最后失败的干扰数据，有用的次数减1
            with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                f.write(f"{i}次循环通信干扰决策\n")
                f.write(f"程序运行时长: {elapsed_time} 秒\n")
                f.write("layout_result数据:\n")
                for item in layout_result:
                    f.write(f"{item}\n")




            break  # 通信干扰失败，停止循环


    layout_result = load_layout_result()
    print("干扰失败后，最后更新后的 干扰机layout_result：", layout_result)


if __name__ == '__main__':
    for _ in range(1):  #程序运行30次
        main()