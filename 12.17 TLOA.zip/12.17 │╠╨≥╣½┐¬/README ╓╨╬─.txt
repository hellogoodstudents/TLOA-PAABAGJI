本论文设计的TLOA算法
运行python集成开发环境（IDE）版本：
PyCharm 2023.2.1 (Professional Edition)
Runtime version: 17.0.8+7-b1000.8 amd64
搭载的第三方库：anaconda_depends_2023.09  以及  PyTorch版本: 1.13.1  

场景绘图 文件夹内的 Scenario 1. 、 Scenario 2.、 Scenario 3.、Scenario 4.的绘制程序，直接运行即可生成图像。

在每个场景文件中：
1.打开main，点击运行可以直接按照默认设置，运行一次本算法，修改程序最后的运行次数，可以重复运行/
2.generate_nodes.py为通信节点初始功率的仿真程序。
3.modify_communication_nodes.py为通信节点动态功率调整的仿真程序。
4.jammer_first_run.py为干扰方依据策略第一次决策的干扰程序。
5.jammer_run.py为干扰方依据策略非第一次决策的干扰程序。
6.test.py为仿真场景中干扰效果的检测程序。
7.点击运行“数据统计”程序，可以计算出论文中的对比数据.

