import numpy as np
#这个程序的整体思路是，依据传输路径损耗排序，先计算出通信节点的最低的发信功率，再计算通信节点的最大收信功率。但部分通信节点，能够发信，收信功率达不到正常标准，处于单向通信。
#通信节点部属中，存在只收不发的，即4号空中节点，只能接收，无法有效的发送信号给通信节点
#序号、类型（1为空中站，2为地面站）、x坐标、y坐标、z坐标、天线高度、威慑度、频段、与该节点路径损耗最小的通信目标节点、该节点的最低发信功率、该节点的最大收信功率

def generate_nodes(nodes_first):
    # 视距传播损耗计算公式，其中d为干扰机与通信设备的间距，f=600
    L_sight = lambda d: 30 * np.log10(d) + 20 * np.log10(600) + 32.5

    # 双线传播损耗计算公式，其中d为干扰机与通信设备的间距，h_t和h_r数值依据干扰机类型与通信节点类型进行定义
    L_two_ray = lambda d, h_t, h_r: (
        40 * np.log10(d) - 20 * np.log10(max(h_t, 1e-10)) - 20 * np.log10(max(h_r, 1e-10)) + 120
    )

    # 通信节点发信功率的计算，Gtr为链路功率增益，Lpc取固定值1。视距传播中Lc_j为L_sight，双线传播中Lc_j为L_two_ray
    Pt_j_min = lambda Gtr, Lc_j: -103 - Gtr + Lc_j + 1  # 设定本场景中，通信设备的通信链路裕量为12dB，环境噪声为-115dBW，通信设备接受灵敏度为-127dBW，即要求通信设备的收信功率要大于-103dBW,程序有0.5的单位转化损耗

    # 将列表转换为numpy数组以便于处理
    nodes = np.array(nodes_first, dtype=object)  # 使用dtype=object以支持混合类型

    # 初始化第8列和第9列
    nodes = np.hstack((nodes, np.zeros((nodes.shape[0], 2), dtype=object)))

    # 遍历所有节点
    for i in range(nodes.shape[0]):
        min_Lc_j = float('inf')  # 初始化最小路径损耗为正无穷
        min_node_id = 0  # 初始化最小路径损耗对应的节点编号

        for j in range(nodes.shape[0]):
            if i == j or nodes[j, 6] != nodes[i, 6]:  # 跳过自身和不同频段的节点
                continue
            else:
                # 计算节点间的距离
                d = np.sqrt((nodes[i, 2] - nodes[j, 2]) ** 2 + (nodes[i, 3] - nodes[j, 3]) ** 2 + (nodes[i, 4] - nodes[j, 4]) ** 2) / 1000

                # 根据节点类型选择传播损耗公式
                if nodes[i, 1] == 2 and nodes[j, 1] == 2:
                    Lc_j = L_two_ray(d, nodes[i, 4], nodes[j, 4])
                else:
                    Lc_j = L_sight(d)

                # 更新最小路径损耗和对应的节点编号
                if Lc_j < min_Lc_j:
                    min_Lc_j = Lc_j
                    min_node_id = nodes[j, 0]

        # 将最小路径损耗对应的节点编号添加到第8列
        nodes[i, 7] = int(min_node_id)  # 存储为整数

        # 计算最小发信功率并添加到第9列
        if min_Lc_j != float('inf'):
            # 根据节点类型确定Gtr
            if nodes[i, 1] == 1 and nodes[int(min_node_id - 1), 1] == 1:
                Gtr = 4
            elif nodes[i, 1] == 2 and nodes[int(min_node_id - 1), 1] == 2:
                Gtr = 5
            else:
                Gtr = 4.5

            Pt_min0 = Pt_j_min(Gtr, min_Lc_j)  # 计算最小发信功率dBW
            if nodes[i, 1] == 1 and Pt_min0 < 10:  # 对于空中站，最大发信功率为17.78dBW,60w
                Pt_min = Pt_min0
            else:
                if nodes[i, 1] == 2 and Pt_min0 < 13.98:  # 对于地面站，最大发信功率为21.76dBW，即150w
                    Pt_min = Pt_min0
                else:
                    Pt_min = -1000  # 最小发信功率为0w ,无法有效通信

            nodes[i, 8] = round(float(Pt_min), 2)  # 存储为保留两位小数的浮点数

    # 新增第10列，初始值为-1000
    nodes = np.hstack((nodes, np.full((nodes.shape[0], 1), -1000, dtype=object)))

    # 计算每个通信节点的最大收信功率并更新第10列
    for i in range(nodes.shape[0]):
        max_Pr = -1000  # 初始化最大收信功率为-1000
        for j in range(nodes.shape[0]):
            if i == j or nodes[j, 6] != nodes[i, 6]:  # 跳过自身和不同频段的节点
                continue
            else:
                # 获取目标节点的发送功率
                Pt_min = nodes[j, 8]
                if Pt_min != -1000:  # 如果目标节点的发送功率有效
                    # 计算收信功率
                    # 根据节点类型确定Gtr
                    if nodes[i, 1] == 1 and nodes[j, 1] == 1:
                        Gtr = 4
                    elif nodes[i, 1] == 2 and nodes[j, 1] == 2:
                        Gtr = 5
                    else:
                        Gtr = 4.5

                    d = np.sqrt((nodes[i, 2] - nodes[j, 2]) ** 2 + (nodes[i, 3] - nodes[j, 3]) ** 2 + (
                                nodes[i, 4] - nodes[j, 4]) ** 2) / 1000
                    if nodes[i, 1] == 2 and nodes[j, 1] == 2:
                        Lc_j = L_two_ray(d, nodes[i, 4], nodes[j, 4])
                    else:
                        Lc_j = L_sight(d)
                    # 计算收信功率
                    Pr = Pt_min + Gtr - Lc_j - 1  # 通信节点的线缆损耗为1dB
                    if Pr > max_Pr:  # 更新最大收信功率
                        max_Pr = Pr

        # 更新第10列为最大收信功率
        nodes[i, 9] = round(float(max_Pr), 2)  # 存储为保留两位小数的浮点数


    # 遍历每个通信节点，如果该通信节点的最大收信功率小于-95dBW,反向计算与通信节点路径损耗虽小节点的发送功率，并判断更新
    for i in range(nodes.shape[0]):
        if nodes[i, 9] < -103:

            # 找到与该节点路径损耗最小的通信目标节点
            min_node_id = nodes[i, 7] - 1

            # 计算节点间的距离
            d = np.sqrt((nodes[i, 2] - nodes[min_node_id, 2]) ** 2 + (nodes[i, 3] - nodes[min_node_id, 3]) ** 2 + (
                    nodes[i, 4] - nodes[min_node_id, 4]) ** 2) / 1000

            # 根据节点类型选择传播损耗公式
            if nodes[i, 1] == 2 and nodes[min_node_id, 1] == 2:
                Lc_j = L_two_ray(d, nodes[i, 4], nodes[min_node_id, 4])

            else:
                Lc_j = L_sight(d)

            # 计算这个通信节点的发信功率
            if nodes[i, 1] == 1 and nodes[min_node_id, 1] == 1:
                Gtr = 4
            elif nodes[i, 1] == 2 and nodes[min_node_id, 1] == 2:
                Gtr = 5
            else:
                Gtr = 4.5

            Pt_min0 = Pt_j_min(Gtr, Lc_j)  # 计算最小发信功率
            Pt_min0 = round(float(Pt_min0 ), 2)
            if nodes[i, 1] == 1 and Pt_min0 < 10 and nodes[min_node_id, 8] < Pt_min0:  # 对于空中站，最大发信功率为10dBW,10w
                nodes[min_node_id, 8] = Pt_min0
                nodes[i, 9] = -103
            else:
                if nodes[i, 1] == 2 and Pt_min0 < 13.98 and nodes[min_node_id, 8] < Pt_min0:  # 对于地面站，最大发信功率为13.98dBW，即25w
                    nodes[min_node_id, 8] = Pt_min0
                    nodes[i, 9] = -103
                else:
                    pass

    # 再次计算每个通信节点的最大收信功率并更新第10列
    for i in range(nodes.shape[0]):
        max_Pr = -1000  # 初始化最大收信功率为-1000
        for j in range(nodes.shape[0]):
            if i == j or nodes[j, 6] != nodes[i, 6]:  # 跳过自身和不同频段的节点
                continue
            else:
                # 获取目标节点的发送功率
                Pt_min = nodes[j, 8]
                if Pt_min != -1000:  # 如果目标节点的发送功率有效
                    # 计算收信功率
                    # 根据节点类型确定Gtr
                    if nodes[i, 1] == 1 and nodes[j, 1] == 1:
                        Gtr = 4
                    elif nodes[i, 1] == 2 and nodes[j, 1] == 2:
                        Gtr = 5
                    else:
                        Gtr = 4.5
                    d = np.sqrt((nodes[i, 2] - nodes[j, 2]) ** 2 + (nodes[i, 3] - nodes[j, 3]) ** 2 + (nodes[i, 4] - nodes[j, 4]) ** 2) / 1000
                    if nodes[i, 1] == 2 and nodes[j, 1] == 2:
                        Lc_j = L_two_ray(d, nodes[i, 4], nodes[j, 4])
                    else:
                        Lc_j = L_sight(d)
                    # 计算收信功率

                    Pr = Pt_min + Gtr - Lc_j - 1  # 通信节点的线缆损耗为1dB
                    #print('', nodes[i, 0], nodes[j, 0], Pt_min, Gtr, Lc_j, Pr)
                    if Pr > max_Pr:  # 更新最大收信功率
                        max_Pr = Pr

        # 更新第10列为最大收信功率
        nodes[i, 9] = round(float(max_Pr), 2)  # 存储为保留两位小数的浮点数

    return nodes