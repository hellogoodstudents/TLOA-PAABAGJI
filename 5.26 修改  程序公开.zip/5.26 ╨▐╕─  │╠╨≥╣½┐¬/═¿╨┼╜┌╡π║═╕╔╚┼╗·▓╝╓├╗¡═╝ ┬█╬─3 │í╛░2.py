import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 设置支持中文的字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置中文字体为黑体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 通信节点数据
nodes_first = [
    [1, 2, 42800, 6500, 5, 0.71, -89.24],
    [2, 2, 5800, 45800, 5, 0.2, -93.54],
    [3, 2, 4600, 27300, 5, 0.96, -95.58],
    [4, 2, 32100, 18600, 5, 0.67, -100.94],
    [5, 2, 17200, 38400, 5, 0.63, -95.61],
    [6, 1, 36700, 45800, 1800, 0.55, -96.42],
    [7, 1, 46300, 4600, 1300, 0.9, -93.22],
    [8, 1, 11000, 35900, 1400, 0.25, -93.69],
    [9, 1, 44600, 33500, 1500, 0.18, -96.53],
    [10, 1, 9000, 41200, 1600, 0.42, -93.69],
    [11, 1, 26200, 5800, 1300, 0.56, -94.63],
    [12, 1, 3500, 10000, 1400, 0.48, -105.58],
    [13, 1, 29200, 500, 1500, 0.78, -94.63],
    [14, 1, 21600, 12600, 1700, 0.38, -98.53],
    [15, 1, 38600, 29800, 1600, 0.85, -96.53],
    [16, 1, 15200, 17900, 1700, 0.79, -97.69],
    [17, 1, 10400, 23900, 1100, 0.74, -97.69],
    [18, 1, 46900, 17400, 1200, 0.06, -104.31],
    [19, 1, 29800, 44800, 1300, 0.09, -96.42],
    [20, 1, 23200, 23600, 1200, 0.89, -100.87],
]

# 干扰机数据
layout_result = [
    [1, 0, 45411, 3073, 3],
    [2, 0, 40148, 28784, 3],
    [3, 1, 5444, 7687, 1819],
    [4, 0, 37601, 47357, 3],
    [5, 0, 27096, 5219, 3],
    [6, 0, 5221, 45041, 3],
    [7, 0, 29570, 0, 3],
    [8, 0, 14702, 18333, 3],
    [9, 0, 23887, 25119, 3],
    [10, 0, 29295, 43702, 3],
    [11, 0, 10416, 35278, 3],
    [12, 0, 30204, 19230, 3],
    [13, 0, 43573, 32837, 3],
    [14, 0, 48816, 15859, 3],
    [15, 0, 22252, 13016, 3],
    [16, 0, 9996, 25153, 3],
    [17, 0, 15226, 38995, 3],
    [18, 1, 43154, 7709, 1152],
    [19, 0, 3937, 28022, 3],
    [20, 0, 7343, 40478, 3],
    [21, 0, 9932, 41857, 3],
    [22, 0, 9843, 39410, 3],
    [23, 0, 8149, 39795, 3],


]

# 创建图形
plt.figure(figsize=(10, 10))

# 绘制通信节点
for node in nodes_first:
    node_id, node_type, x, y, z, _, _, = node
    if node_type == 1:  # 空中通信节点
        plt.scatter(x, y, color='green', marker='^', s=100, label='空中通信节点' if node_type== 1 else "")
    elif node_type == 2:  # 地面通信节点
        plt.scatter(x, y, color='blue', marker='^', s=100, label='地面通信节点' if node_type == 2 else "")

# 绘制干扰机
for jammer in layout_result:
    jammer_id, jammer_type, x, y, z, = jammer
    if jammer_type == 0:  # 地面干扰机
        plt.scatter(x, y, color='black', marker='*', s=200, label='地面干扰机' if jammer_type == 0 else "")
    elif jammer_type == 1:  # 空中干扰机
        plt.scatter(x, y, color='red', marker='*', s=200, label='空中干扰机' if jammer_type == 1 else "")

# 设置图例
handles, labels = plt.gca().get_legend_handles_labels()
by_label = dict(zip(labels, handles))  # 去重
plt.legend(by_label.values(), by_label.keys(), loc='upper right',fontsize=14)


# 设置标题和坐标轴标签，增大字体大小
#plt.title("通信节点和干扰机分布图", fontsize=20)
#plt.xlabel("X 坐标", fontsize=16)
#plt.ylabel("Y 坐标", fontsize=16)

# 增大坐标轴刻度数值的字体大小
plt.xticks(fontsize=25)
plt.yticks(fontsize=25)


# 显示图形
plt.grid(False)
plt.show()






