import numpy as np

# 通信节点数据
communication_nodes = [
    [1, 1, 2300, 7600, 2500, -107],
    [2, 1, 4800, 20000, 2100, -112],
    [3, 1, 11600, 4700, 2900, -112],
    [4, 1, 18000, 5300, 2100, -113],
    [5, 1, 26800, 5700, 2700, -107],
    [6, 1, 39000, 25800, 2200, -115],
    [7, 1, 25200, 44200, 2400, -108],
    [8, 1, 19000, 45000, 2800, -108],
    [9, 1, 22900, 6700, 2700, -112],
    [10, 1, 37000, 40800, 2600, -111],
    [11, 2, 5000, 3000, 5, -96],
    [12, 2, 6000, 13000, 5, -98],
    [13, 2, 5500, 23500, 5, -101],
    [14, 2, 4300, 29000, 5, -105],
    [15, 2, 5300, 34300, 5, -97],
    [16, 2, 5900, 40200, 5, -96],
    [17, 2, 4500, 46400, 5, -104],
    [18, 2, 9500, 44700, 5, -104],
    [19, 2, 13000, 39200, 5, -98],
    [20, 2, 20900, 37000, 5, -104],
    [21, 2, 30200, 39700, 5, -98],
    [22, 2, 40900, 39700, 5, -97],
    [23, 2, 43800, 36800, 5, -95],
    [24, 2, 38300, 35300, 5, -103],
    [25, 2, 38700, 29900, 5, -104],
    [26, 2, 38700, 20400, 5, -105],
    [27, 2, 37100, 16000, 5, -101],
    [28, 2, 3800, 10800, 5, -96],
    [29, 2, 37000, 4800, 5, -103],
    [30, 2, 31800, 4700, 5, -98],
]

# 定义参数
# 定义天线增益 (dB)
ant_gain_ground = 2.5  # 地面站通信节点的发送端和接收端的天线增益
ant_gain_air = 2  # 空中站通信节点的发送端和接收端的天线增益

# 定义发送功率 (dBW)
Pt_ground = 10  # 地面站通信节点的发送功率
Pt_air = 13.98  # 空中站通信节点的发生功率

f = 600  # 电磁波频率 (MHz)

Lpc = 1  # 通信收信端电缆和缆头的衰耗 (dB)


def calculate_max_rx_power(communication_nodes):
    max_rx_power_list = []

    for node in communication_nodes:
        node_type = node[1]
        x_coord = node[2]
        y_coord = node[3]
        height = node[4]

        # 找到距离当前节点最近的各类型节点
        nearest_air_station = None
        nearest_ground_station = None
        min_distance_air = float('inf')
        min_distance_ground = float('inf')

        for other_node in communication_nodes:
            if other_node == node:  # 跳过当前节点自身
                continue

            other_node_type = other_node[1]
            other_x_coord = other_node[2]
            other_y_coord = other_node[3]
            other_height = other_node[4]
            distance = int(np.sqrt(np.round((x_coord - other_x_coord) ** 2 + (y_coord - other_y_coord) ** 2 + (height - other_height) ** 2)))/1000

            if other_node_type == 1 and distance < min_distance_air:
                min_distance_air = distance
                nearest_air_station = other_node
            elif other_node_type == 2 and distance < min_distance_ground:
                min_distance_ground = distance
                nearest_ground_station = other_node


        # 根据节点类型和最近节点类型计算相关参数及收信功率
        if node_type == 1:
            Gt_c = ant_gain_air
            air_rx_power = None
            ground_rx_power = None

            # 距离最近的空中站通信节点
            if nearest_air_station:
                other_type = nearest_air_station[1]
                Pt_c = Pt_air
                Gr_c = ant_gain_air
                d = min_distance_air
                Lc_c = 30 * np.log10(d) + 20 * np.log10(f) + 32.5
                air_rx_power = Pt_c + Gt_c + Gr_c - Lc_c - Lpc

            # 距离最近的地面站通信节点
            if nearest_ground_station:
                other_type = nearest_ground_station[1]
                Pt_c = Pt_ground
                Gr_c = ant_gain_ground
                d = min_distance_ground
                Lc_c = 30 * np.log10(d) + 20 * np.log10(f) + 32.5
                ground_rx_power = Pt_c + Gt_c + Gr_c - Lc_c - Lpc

            max_rx_power = max(air_rx_power, ground_rx_power)
            max_rx_power_list.append(max_rx_power)

        elif node_type == 2:
            Gt_c = ant_gain_ground
            air_rx_power = None
            ground_rx_power = None

            # 距离最近的空中站通信节点
            if nearest_air_station:
                other_type = nearest_air_station[1]
                Pt_c = Pt_air
                Gr_c = ant_gain_air
                d = min_distance_air
                Lc_c = 30 * np.log10(d) + 20 * np.log10(f) + 32.5
                air_rx_power = Pt_c + Gt_c + Gr_c - Lc_c - Lpc

            # 距离最近的地面站通信节点
            if nearest_ground_station:
                other_type = nearest_ground_station[1]
                Pt_c = Pt_ground
                Gr_c = ant_gain_ground
                d = min_distance_ground
                Lc_c = 40 * np.log10(d) - 20 * np.log10(nearest_ground_station[4]) - 20 * np.log10(height) + 120
                ground_rx_power = Pt_c + Gt_c + Gr_c - Lc_c - Lpc

            max_rx_power = max(air_rx_power, ground_rx_power)
            max_rx_power_list.append(max_rx_power)

    return max_rx_power_list


max_rx_powers = calculate_max_rx_power(communication_nodes)
max_rx_powers = [round(power, 2) for power in calculate_max_rx_power(communication_nodes)]
# 将最大收信功率添加到通信节点数据每行的第七列
for i, power in enumerate(max_rx_powers):
    communication_nodes[i].append(power)

# 输出更新后的通信节点数据矩阵
for row in communication_nodes:
    print(row)

