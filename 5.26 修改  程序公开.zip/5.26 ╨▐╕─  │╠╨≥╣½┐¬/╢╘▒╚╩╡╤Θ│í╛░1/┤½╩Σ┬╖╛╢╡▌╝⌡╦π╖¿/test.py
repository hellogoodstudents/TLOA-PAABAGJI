import numpy as np

# 干信比三倍，相当于4.77dB

# 视距传播损耗计算公式，其中d为干扰机与通信设备的间距，f=600
L_sight = lambda d: 30 * np.log10(d) + 20 * np.log10(600) + 32.5

# 双线传播损耗计算公式，其中d为干扰机与通信设备的间距，h_t和h_r数值依据干扰机类型与通信节点类型进行定义
L_two_ray = lambda d, h_t, h_r: 40 * np.log10(d) - 20 * np.log10(h_t) - 20 * np.log10(h_r) + 120

# 通信节点接收干扰功率的计算，Gtr为链路功率增益，Lpc取固定值1。视距传播中Lc_j为L_sight，双线传播中Lc_j为L_two_ray，Pt_j 为干扰机的干扰功率数值
Prj = lambda Pt_j, Gtr, Lc_j: Pt_j + Gtr - Lc_j - 1


# 干扰取链路裕量1倍
Interference_distance = [
    [3, 4.77, 15, 20],
]



def reprocess_interference2(jammers, communication):
    all_communication_copies = []
    communication_copy = [row.copy() for row in communication]  # 创建communication的副本进行操作

    # 为 communication_copy 列表新增第 8 列，初始值为 0 便于后期干扰功率的叠加
    for row in communication_copy:
        row.append(0)

    for jammer_row in jammers:
        jammer_type = jammer_row[1]
        jammer_power_W = jammer_row[5]
        jammer_power_dBW = 10 * np.log10(jammer_power_W) if jammer_power_W > 0 else float('-inf')

        for communication_row in communication_copy:
            communication_type = communication_row[1]
            x_distance = abs(jammer_row[2] - communication_row[2])
            y_distance = abs(jammer_row[3] - communication_row[3])
            z_distance = abs(jammer_row[4] - communication_row[4])

            distance = np.sqrt((x_distance / 1000) ** 2 + (y_distance / 1000) ** 2 + (z_distance / 1000) ** 2)
            distance = round(distance, 2)

            if jammer_type == 0 and communication_type == 2:  # 地面干扰机对地面通信节点的影响
                interference_distance = Interference_distance[0][2]  # 双线传播的纳入计算的范围
                Gtr = 4.5
                h_t = 5
                h_r = 3
                Lc_j = L_two_ray(distance, h_t, h_r)
            else:
                Lc_j = L_sight(distance)
                interference_distance = Interference_distance[0][3]  # 视距传播的纳入计算的范围
                if communication_type == 2:  # 空中干扰机对地面通信节点的影响
                    Gtr = 4.5
                else:  # 干扰机对空中通信节点的影响
                    Gtr = 4

            if interference_distance is not None and distance <= interference_distance:
                interference_power_dBW = Prj(jammer_power_dBW, Gtr, Lc_j)
                interference_power_W = 10 ** (interference_power_dBW / 10) if interference_power_dBW != float('-inf') else 0
                if communication_row[8] == 0:  # 如果该行的第7列（索引为6）为0，则将干扰功率添加到第7列
                    communication_row[8] = interference_power_W + 3.16e-12
                else:
                        communication_row[8] += interference_power_W

    # 将各通信节点收到的干扰总和转化为dBW形式并更新communication副本矩阵，避免出现log10(0)或负数的情况
    for communication_row in communication_copy:
        if len(communication_row) >= 9 and communication_row[8] > 0:
            total_interference_dBW = round(10 * np.log10(communication_row[8]), 2)
            communication_row[8] = total_interference_dBW
        elif len(communication_row) >= 8:  # 这里添加判断，确保列表长度足够
            communication_row[8] = (float('-1000'))  #-1000dBW
    all_communication_copies.append(communication_copy)
    return all_communication_copies

def run_test(communication, jammer):
    """
    运行测试，检查干扰是否符合干信比为3的要求。
    """

    test_result = reprocess_interference2(jammer, communication)
    warnings = []
    print('test_result',test_result)

    for row0 in test_result:
        for row in row0:
            if row[8] - row[7] < 4.77:
                warnings.append(f"通信节点{row} 不符合干信比为3的干扰")

    if not warnings:
        return {"success": True, "warnings": []}
    else:
        return {"success": False, "warnings": warnings}




if __name__ == "__main__":
    # 从文件中加载 communication 和 jammer
    import pickle
    with open("communication.pkl", "rb") as f:
        communication = pickle.load(f)
        print('读取的communication',communication)
    with open("layout_result.pkl", "rb") as f:
        layout_result = pickle.load(f)
        print('读取的layout_result',layout_result)
        # 只保留前6列，不考虑能量剩余，在干扰机功率设置中已考虑
        jammer = [row[:6] for row in layout_result ]



    # 运行测试
    result = run_test(communication, jammer)

    if result["success"]:
        print("通信干扰成功！")
    else:
        print("以下干扰机不符合干信比为3的干扰：")
        for warning in result["warnings"]:
            print(warning)